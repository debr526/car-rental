import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// API base URL for edge functions
const API_BASE = `${supabaseUrl}/functions/v1/api`;

export async function apiRequest(endpoint: string, options: RequestInit = {}, token?: string) {
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...options.headers,
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers,
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || 'Request failed');
  }

  return data;
}

// Auth API
export const authApi = {
  signup: async (email: string, password: string, fullName: string, phone?: string) => {
    const data = await apiRequest('/auth/signup', {
      method: 'POST',
      body: JSON.stringify({ email, password, fullName, phone }),
    });
    return data;
  },

  login: async (email: string, password: string) => {
    const data = await apiRequest('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    return data;
  },

  getProfile: async (token: string) => {
    return apiRequest('/auth/me', {}, token);
  },
};

// Cars API
export const carsApi = {
  getAll: async (filters: Record<string, string> = {}, token?: string) => {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value) params.append(key, value);
    });
    const query = params.toString() ? `?${params.toString()}` : '';
    return apiRequest(`/cars${query}`, {}, token);
  },

  getById: async (id: string, token?: string) => {
    return apiRequest(`/cars/${id}`, {}, token);
  },

  create: async (carData: Record<string, unknown>, token: string) => {
    return apiRequest('/cars', {
      method: 'POST',
      body: JSON.stringify(carData),
    }, token);
  },

  update: async (id: string, updates: Record<string, unknown>, token: string) => {
    return apiRequest(`/cars/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    }, token);
  },

  delete: async (id: string, token: string) => {
    return apiRequest(`/cars/${id}`, {
      method: 'DELETE',
    }, token);
  },
};

// Categories API
export const categoriesApi = {
  getAll: async () => {
    return apiRequest('/categories');
  },

  create: async (data: Record<string, unknown>, token: string) => {
    return apiRequest('/categories', {
      method: 'POST',
      body: JSON.stringify(data),
    }, token);
  },
};

// Rentals API
export const rentalsApi = {
  getAll: async (filters: Record<string, string> = {}, token: string) => {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value) params.append(key, value);
    });
    const query = params.toString() ? `?${params.toString()}` : '';
    return apiRequest(`/rentals${query}`, {}, token);
  },

  getById: async (id: string, token: string) => {
    return apiRequest(`/rentals/${id}`, {}, token);
  },

  create: async (rentalData: Record<string, unknown>, token: string) => {
    return apiRequest('/rentals', {
      method: 'POST',
      body: JSON.stringify(rentalData),
    }, token);
  },

  update: async (id: string, updates: Record<string, unknown>, token: string) => {
    return apiRequest(`/rentals/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    }, token);
  },

  cancel: async (id: string, token: string) => {
    return apiRequest(`/rentals/${id}/cancel`, {
      method: 'POST',
    }, token);
  },

  getStats: async (token: string) => {
    return apiRequest('/rentals/stats', {}, token);
  },
};

// Users API
export const usersApi = {
  getProfile: async (token: string) => {
    return apiRequest('/users/profile', {}, token);
  },

  updateProfile: async (updates: Record<string, unknown>, token: string) => {
    return apiRequest('/users/profile', {
      method: 'PUT',
      body: JSON.stringify(updates),
    }, token);
  },
};
