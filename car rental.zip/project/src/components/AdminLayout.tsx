import { useState, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import {
  LayoutDashboard, Car, Calendar, Users, Tag, LogOut, Menu, X, ChevronRight, Store
} from 'lucide-react';

interface AdminLayoutProps {
  children: React.ReactNode;
  currentPage: string;
  onNavigate: (page: string) => void;
}

export function AdminLayout({ children, currentPage, onNavigate }: AdminLayoutProps) {
  const { user, signOut } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'cars', label: 'Manage Cars', icon: Car },
    { id: 'bookings', label: 'Manage Bookings', icon: Calendar },
    { id: 'users', label: 'Manage Users', icon: Users },
    { id: 'categories', label: 'Manage Categories', icon: Tag },
  ];

  const NavItem = ({ item }: { item: typeof navItems[0] }) => (
    <button
      onClick={() => {
        onNavigate(item.id);
        setSidebarOpen(false);
      }}
      className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-colors ${
        currentPage === item.id
          ? 'bg-emerald-100 text-emerald-700 font-medium'
          : 'text-gray-600 hover:bg-gray-100'
      }`}
    >
      <item.icon className="h-5 w-5" />
      <span>{item.label}</span>
      {currentPage === item.id && <ChevronRight className="h-4 w-4 ml-auto" />}
    </button>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile Header */}
      <header className="lg:hidden bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between sticky top-0 z-40">
        <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-2 rounded-lg hover:bg-gray-100">
          {sidebarOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
            <LayoutDashboard className="h-4 w-4 text-white" />
          </div>
          <span className="font-semibold text-gray-900">Admin Panel</span>
        </div>
        <button onClick={signOut} className="p-2 rounded-lg hover:bg-gray-100">
          <LogOut className="h-5 w-5 text-gray-500" />
        </button>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className={`
          fixed inset-y-0 left-0 z-30 w-64 bg-white border-r border-gray-200 transform transition-transform duration-300 ease-in-out
          lg:translate-x-0 lg:static lg:transform-none
          ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}
        `}>
          {/* Logo */}
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-600/30">
                <LayoutDashboard className="h-5 w-5 text-white" />
              </div>
              <div>
                <h1 className="font-bold text-gray-900">QuickReserve</h1>
                <p className="text-xs text-gray-500">Admin Dashboard</p>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <nav className="p-4 space-y-1">
            {navItems.map((item) => (
              <NavItem key={item.id} item={item} />
            ))}
          </nav>

          {/* User Info */}
          <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-200">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center">
                <Users className="h-5 w-5 text-emerald-600" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">{user?.full_name || 'Admin'}</p>
                <p className="text-xs text-gray-500 truncate">{user?.email}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => window.location.href = '/'}
                className="flex-1 flex items-center justify-center gap-2 px-3 py-2 text-sm text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <Store className="h-4 w-4" />
                <span>View Site</span>
              </button>
              <button
                onClick={signOut}
                className="flex-1 flex items-center justify-center gap-2 px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              >
                <LogOut className="h-4 w-4" />
                <span>Logout</span>
              </button>
            </div>
          </div>
        </aside>

        {/* Overlay for mobile */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 bg-black/50 z-20 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Main Content */}
        <main className="flex-1 min-h-screen lg:min-h-0">
          {/* Desktop Header */}
          <header className="hidden lg:block bg-white border-b border-gray-200 px-8 py-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 capitalize">{currentPage}</h2>
                <p className="text-sm text-gray-500">
                  {currentPage === 'dashboard' && 'Overview of your car rental business'}
                  {currentPage === 'cars' && 'Manage your vehicle fleet'}
                  {currentPage === 'bookings' && 'View and manage customer reservations'}
                  {currentPage === 'users' && 'View and manage user accounts'}
                  {currentPage === 'categories' && 'Manage vehicle categories'}
                </p>
              </div>
              <div className="flex items-center gap-4">
                <span className="px-3 py-1 bg-emerald-100 text-emerald-700 text-sm font-medium rounded-full">
                  Admin
                </span>
              </div>
            </div>
          </header>

          <div className="p-4 lg:p-8">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}