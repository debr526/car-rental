import { useState, useEffect } from 'react';
import { Car, Users, Calendar, DollarSign, TrendingUp, Clock, AlertCircle } from 'lucide-react';

interface Stats {
  totalCars: number;
  availableCars: number;
  totalUsers: number;
  totalBookings: number;
  pendingBookings: number;
  activeBookings: number;
  totalRevenue: number;
}

export function AdminDashboard() {
  const [stats, setStats] = useState<Stats>({
    totalCars: 0,
    availableCars: 0,
    totalUsers: 0,
    totalBookings: 0,
    pendingBookings: 0,
    activeBookings: 0,
    totalRevenue: 0,
  });
  const [loading, setLoading] = useState(true);
  const [recentBookings, setRecentBookings] = useState<unknown[]>([]);

  useEffect(() => {
    fetchStats();
    fetchRecentBookings();
  }, []);

  async function fetchStats() {
    const token = localStorage.getItem('token');
    if (!token) return;

    try {
      const baseUrl = import.meta.env.VITE_SUPABASE_URL;

      // Fetch all stats in parallel
      const [carsRes, usersRes, bookingsRes] = await Promise.all([
        fetch(`${baseUrl}/functions/v1/api/cars?limit=1`, {
          headers: { Authorization: `Bearer ${token}` }
        }),
        fetch(`${baseUrl}/functions/v1/api/admin/users?limit=1`, {
          headers: { Authorization: `Bearer ${token}` }
        }).catch(() => ({ ok: false, json: () => ({ total: 0 }) })),
        fetch(`${baseUrl}/functions/v1/api/rentals/stats`, {
          headers: { Authorization: `Bearer ${token}` }
        })
      ]);

      const carsData = await carsRes.json();
      let usersCount = 0;

      // Try to get users count from profiles
      try {
        const supabase = (await import('../lib/api')).supabase;
        const { count } = await supabase.from('profiles').select('*', { count: 'exact', head: true });
        usersCount = count || 0;
      } catch {
        usersCount = 0;
      }

      const bookingsData = await bookingsRes.json();

      // Get available cars count
      const available = carsData.cars?.filter((c: { status: string }) => c.status === 'available').length || 0;

      setStats({
        totalCars: carsData.pagination?.total || carsData.cars?.length || 0,
        availableCars: available,
        totalUsers: usersCount,
        totalBookings: bookingsData.stats?.total || 0,
        pendingBookings: bookingsData.stats?.pending || 0,
        activeBookings: bookingsData.stats?.active || 0,
        totalRevenue: bookingsData.stats?.totalRevenue || 0,
      });
    } catch (error) {
      console.error('Failed to fetch stats:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchRecentBookings() {
    const token = localStorage.getItem('token');
    if (!token) return;

    try {
      const baseUrl = import.meta.env.VITE_SUPABASE_URL;
      const response = await fetch(`${baseUrl}/functions/v1/api/rentals?limit=5`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await response.json();
      setRecentBookings(data.rentals || []);
    } catch (error) {
      console.error('Failed to fetch recent bookings:', error);
    }
  }

  const StatCard = ({ title, value, subtitle, icon: Icon, color }: {
    title: string;
    value: string | number;
    subtitle?: string;
    icon: typeof Car;
    color: string;
  }) => (
    <div className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-gray-500 font-medium">{title}</p>
          <p className="text-3xl font-bold text-gray-900 mt-1">{value}</p>
          {subtitle && <p className="text-sm text-gray-500 mt-1">{subtitle}</p>}
        </div>
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${color}`}>
          <Icon className="h-6 w-6 text-white" />
        </div>
      </div>
    </div>
  );

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-white rounded-xl shadow-sm p-6 animate-pulse">
              <div className="h-4 bg-gray-200 rounded w-24" />
              <div className="h-8 bg-gray-200 rounded w-16 mt-2" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  const typedRecentBookings = recentBookings as Array<{
    id: string;
    status: string;
    start_date: string;
    end_date: string;
    total_amount: number;
    car?: { make: string; model: string };
    user?: { email: string; full_name: string };
  }>;

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Vehicles"
          value={stats.totalCars}
          subtitle={`${stats.availableCars} available`}
          icon={Car}
          color="bg-emerald-600"
        />
        <StatCard
          title="Total Users"
          value={stats.totalUsers}
          icon={Users}
          color="bg-blue-600"
        />
        <StatCard
          title="Total Bookings"
          value={stats.totalBookings}
          subtitle={`${stats.pendingBookings} pending, ${stats.activeBookings} active`}
          icon={Calendar}
          color="bg-purple-600"
        />
        <StatCard
          title="Total Revenue"
          value={`$${stats.totalRevenue.toLocaleString()}`}
          icon={DollarSign}
          color="bg-amber-600"
        />
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-amber-50 to-amber-100 rounded-xl p-6">
          <div className="flex items-center gap-3">
            <Clock className="h-6 w-6 text-amber-600" />
            <div>
              <p className="text-2xl font-bold text-amber-900">{stats.pendingBookings}</p>
              <p className="text-amber-700">Pending Approvals</p>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-6">
          <div className="flex items-center gap-3">
            <TrendingUp className="h-6 w-6 text-blue-600" />
            <div>
              <p className="text-2xl font-bold text-blue-900">{stats.activeBookings}</p>
              <p className="text-blue-700">Active Rentals</p>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 rounded-xl p-6">
          <div className="flex items-center gap-3">
            <Car className="h-6 w-6 text-emerald-600" />
            <div>
              <p className="text-2xl font-bold text-emerald-900">{stats.availableCars}</p>
              <p className="text-emerald-700">Cars Available</p>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Bookings */}
      <div className="bg-white rounded-xl shadow-sm">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Recent Bookings</h3>
        </div>
        <div className="divide-y divide-gray-100">
          {typedRecentBookings.length === 0 ? (
            <div className="p-8 text-center">
              <Calendar className="h-12 w-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">No bookings yet</p>
            </div>
          ) : (
            typedRecentBookings.map((booking) => (
              <div key={booking.id} className="p-4 hover:bg-gray-50 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                    <Calendar className="h-5 w-5 text-gray-500" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">
                      {booking.car?.make} {booking.car?.model}
                    </p>
                    <p className="text-sm text-gray-500">
                      {booking.user?.full_name || booking.user?.email}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium text-gray-900">${booking.total_amount}</p>
                  <span className={`inline-block px-2 py-0.5 text-xs font-medium rounded-full ${
                    booking.status === 'pending' ? 'bg-amber-100 text-amber-700' :
                    booking.status === 'active' ? 'bg-blue-100 text-blue-700' :
                    booking.status === 'completed' ? 'bg-emerald-100 text-emerald-700' :
                    'bg-red-100 text-red-700'
                  }`}>
                    {booking.status}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}