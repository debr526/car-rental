import { useState, useEffect } from 'react';
import { Calendar, Search, Filter, Eye, CheckCircle, XCircle, X, Clock, AlertCircle } from 'lucide-react';

interface Rental {
  id: string;
  car_id: string;
  user_id: string;
  start_date: string;
  end_date: string;
  total_amount: number;
  status: string;
  pickup_location: string | null;
  return_location: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
  car: {
    id: string;
    make: string;
    model: string;
    year: number;
    license_plate: string;
    image_url: string | null;
    daily_rate: number;
    category?: { id: string; name: string };
  };
  user: {
    id: string;
    email: string;
    full_name: string | null;
    phone: string | null;
  };
}

export function AdminBookings() {
  const [bookings, setBookings] = useState<Rental[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [selectedBooking, setSelectedBooking] = useState<Rental | null>(null);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    fetchBookings();
  }, []);

  async function fetchBookings() {
    setLoading(true);
    const token = localStorage.getItem('token');
    if (!token) return;

    try {
      const baseUrl = import.meta.env.VITE_SUPABASE_URL;
      const response = await fetch(`${baseUrl}/functions/v1/api/rentals?limit=100`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await response.json();
      setBookings(data.rentals || []);
    } catch (error) {
      console.error('Failed to fetch bookings:', error);
    } finally {
      setLoading(false);
    }
  }

  async function updateBookingStatus(booking: Rental, newStatus: string) {
    const token = localStorage.getItem('token');
    if (!token) return;

    try {
      const baseUrl = import.meta.env.VITE_SUPABASE_URL;
      const response = await fetch(`${baseUrl}/functions/v1/api/rentals/${booking.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status: newStatus }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to update');
      }

      // Update car status if needed
      if (newStatus === 'active') {
        await fetch(`${baseUrl}/functions/v1/api/cars/${booking.car_id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ status: 'rented' }),
        });
      } else if (newStatus === 'completed' || newStatus === 'cancelled') {
        await fetch(`${baseUrl}/functions/v1/api/cars/${booking.car_id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ status: 'available' }),
        });
      }

      fetchBookings();
      closeModal();
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Failed to update status');
    }
  }

  function openBookingDetails(booking: Rental) {
    setSelectedBooking(booking);
    setShowModal(true);
  }

  function closeModal() {
    setShowModal(false);
    setSelectedBooking(null);
  }

  const filteredBookings = bookings.filter(booking => {
    const matchesSearch = !searchQuery ||
      booking.car.make.toLowerCase().includes(searchQuery.toLowerCase()) ||
      booking.car.model.toLowerCase().includes(searchQuery.toLowerCase()) ||
      booking.user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      booking.user.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      booking.car.license_plate.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = !statusFilter || booking.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-amber-100 text-amber-700';
      case 'active': return 'bg-blue-100 text-blue-700';
      case 'completed': return 'bg-emerald-100 text-emerald-700';
      case 'cancelled': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const calculateDays = (start: string, end: string) => {
    const startDate = new Date(start);
    const endDate = new Date(end);
    return Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div className="flex-1 flex gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search by car, customer, or plate..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
          >
            <option value="">All Status</option>
            <option value="pending">Pending</option>
            <option value="active">Active</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {['pending', 'active', 'completed', 'cancelled'].map((status) => {
          const count = bookings.filter(b => b.status === status).length;
          return (
            <div key={status} className="bg-white rounded-lg shadow-sm p-4">
              <p className="text-sm text-gray-500 capitalize">{status}</p>
              <p className="text-2xl font-bold text-gray-900">{count}</p>
            </div>
          );
        })}
      </div>

      {/* Bookings Table */}
      {loading ? (
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="bg-white rounded-xl shadow-sm p-6 animate-pulse">
              <div className="h-4 bg-gray-200 rounded w-1/4 mb-3" />
              <div className="h-3 bg-gray-200 rounded w-1/2" />
            </div>
          ))}
        </div>
      ) : filteredBookings.length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm p-12 text-center">
          <Calendar className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">No bookings found</p>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Vehicle</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Customer</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Dates</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredBookings.map((booking) => (
                  <tr key={booking.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4">
                      <div>
                        <p className="font-medium text-gray-900">{booking.car.make} {booking.car.model}</p>
                        <p className="text-sm text-gray-500">{booking.car.license_plate}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div>
                        <p className="font-medium text-gray-900">{booking.user.full_name || 'N/A'}</p>
                        <p className="text-sm text-gray-500">{booking.user.email}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div>
                        <p className="text-sm text-gray-900">{new Date(booking.start_date).toLocaleDateString()}</p>
                        <p className="text-sm text-gray-500">to {new Date(booking.end_date).toLocaleDateString()}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <p className="font-medium text-gray-900">${booking.total_amount}</p>
                      <p className="text-xs text-gray-500">{calculateDays(booking.start_date, booking.end_date)} days</p>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-block px-2 py-1 text-xs font-medium rounded-full capitalize ${getStatusColor(booking.status)}`}>
                        {booking.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => openBookingDetails(booking)}
                          className="p-1.5 text-gray-500 hover:bg-gray-100 rounded-lg"
                          title="View Details"
                        >
                          <Eye className="h-4 w-4" />
                        </button>
                        {booking.status === 'pending' && (
                          <>
                            <button
                              onClick={() => updateBookingStatus(booking, 'active')}
                              className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-lg"
                              title="Approve"
                            >
                              <CheckCircle className="h-4 w-4" />
                            </button>
                            <button
                              onClick={() => updateBookingStatus(booking, 'cancelled')}
                              className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg"
                              title="Reject"
                            >
                              <XCircle className="h-4 w-4" />
                            </button>
                          </>
                        )}
                        {booking.status === 'active' && (
                          <button
                            onClick={() => updateBookingStatus(booking, 'completed')}
                            className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-lg"
                            title="Mark Complete"
                          >
                            <CheckCircle className="h-4 w-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Booking Details Modal */}
      {showModal && selectedBooking && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-lg w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-semibold">Booking Details</h3>
              <button onClick={closeModal} className="p-1 hover:bg-gray-100 rounded-full">
                <X className="h-5 w-5 text-gray-500" />
              </button>
            </div>

            {/* Status */}
            <div className="mb-6">
              <span className={`inline-block px-3 py-1 text-sm font-medium rounded-full capitalize ${getStatusColor(selectedBooking.status)}`}>
                {selectedBooking.status}
              </span>
            </div>

            {/* Vehicle Info */}
            <div className="bg-gray-50 rounded-lg p-4 mb-4">
              <h4 className="text-sm font-medium text-gray-500 mb-2">Vehicle</h4>
              <p className="font-semibold text-gray-900">{selectedBooking.car.make} {selectedBooking.car.model} ({selectedBooking.car.year})</p>
              <p className="text-sm text-gray-600">License: {selectedBooking.car.license_plate}</p>
              <p className="text-sm text-gray-600">Daily Rate: ${selectedBooking.car.daily_rate}</p>
              {selectedBooking.car.category && (
                <p className="text-sm text-gray-600">Category: {selectedBooking.car.category.name}</p>
              )}
            </div>

            {/* Customer Info */}
            <div className="bg-gray-50 rounded-lg p-4 mb-4">
              <h4 className="text-sm font-medium text-gray-500 mb-2">Customer</h4>
              <p className="font-semibold text-gray-900">{selectedBooking.user.full_name || 'N/A'}</p>
              <p className="text-sm text-gray-600">{selectedBooking.user.email}</p>
              {selectedBooking.user.phone && (
                <p className="text-sm text-gray-600">{selectedBooking.user.phone}</p>
              )}
            </div>

            {/* Booking Details */}
            <div className="bg-gray-50 rounded-lg p-4 mb-4">
              <h4 className="text-sm font-medium text-gray-500 mb-2">Rental Details</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-gray-500">Pick-up Date</p>
                  <p className="font-medium text-gray-900">{new Date(selectedBooking.start_date).toLocaleDateString()}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Return Date</p>
                  <p className="font-medium text-gray-900">{new Date(selectedBooking.end_date).toLocaleDateString()}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Duration</p>
                  <p className="font-medium text-gray-900">{calculateDays(selectedBooking.start_date, selectedBooking.end_date)} days</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Total Amount</p>
                  <p className="font-bold text-emerald-600 text-lg">${selectedBooking.total_amount}</p>
                </div>
              </div>
              {selectedBooking.pickup_location && (
                <div className="mt-3 pt-3 border-t border-gray-200">
                  <p className="text-xs text-gray-500">Pick-up Location</p>
                  <p className="text-sm text-gray-900">{selectedBooking.pickup_location}</p>
                </div>
              )}
              {selectedBooking.notes && (
                <div className="mt-3 pt-3 border-t border-gray-200">
                  <p className="text-xs text-gray-500">Notes</p>
                  <p className="text-sm text-gray-900">{selectedBooking.notes}</p>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            {selectedBooking.status === 'pending' && (
              <div className="flex gap-3 pt-4 border-t border-gray-200">
                <button
                  onClick={() => updateBookingStatus(selectedBooking, 'cancelled')}
                  className="flex-1 flex items-center justify-center gap-2 py-2 border border-red-300 text-red-600 rounded-lg font-medium hover:bg-red-50"
                >
                  <XCircle className="h-4 w-4" />
                  Reject
                </button>
                <button
                  onClick={() => updateBookingStatus(selectedBooking, 'active')}
                  className="flex-1 flex items-center justify-center gap-2 py-2 bg-emerald-600 text-white rounded-lg font-medium hover:bg-emerald-700"
                >
                  <CheckCircle className="h-4 w-4" />
                  Approve
                </button>
              </div>
            )}

            {selectedBooking.status === 'active' && (
              <div className="flex gap-3 pt-4 border-t border-gray-200">
                <button
                  onClick={() => updateBookingStatus(selectedBooking, 'completed')}
                  className="flex-1 flex items-center justify-center gap-2 py-2 bg-emerald-600 text-white rounded-lg font-medium hover:bg-emerald-700"
                >
                  <CheckCircle className="h-4 w-4" />
                  Mark as Completed
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}