import { useState, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import { supabase } from '../lib/api';

interface Car {
  id: string;
  make: string;
  model: string;
  year: number;
  license_plate: string;
  daily_rate: number;
  status: string;
  image_url: string | null;
  features: string[];
  category: { id: string; name: string } | null;
}

interface Category {
  id: string;
  name: string;
}

import { Car as CarIcon, Calendar, MapPin, CreditCard, Menu, X, User, LogOut, Plus, XCircle, CheckCircle, Shield } from 'lucide-react';

interface CarsPageProps {
  onAdminClick?: () => void;
}

export function CarsPage({ onAdminClick }: CarsPageProps) {
  const { user, token, signOut } = useAuth();
  const [cars, setCars] = useState<Car[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    category: '',
    status: '',
    minPrice: '',
    maxPrice: '',
    search: '',
  });
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [showAddCarModal, setShowAddCarModal] = useState(false);
  const [selectedCar, setSelectedCar] = useState<Car | null>(null);
  const [activeTab, setActiveTab] = useState<'browse' | 'rentals' | 'admin'>('browse');

  const isAdmin = user?.role === 'admin';

  useEffect(() => {
    fetchCars();
  }, [filters, page]);

  useEffect(() => {
    fetchCategories();
  }, []);

  async function fetchCars() {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (filters.category) params.append('category', filters.category);
      if (filters.status) params.append('status', filters.status);
      if (filters.minPrice) params.append('minPrice', filters.minPrice);
      if (filters.maxPrice) params.append('maxPrice', filters.maxPrice);
      if (filters.search) params.append('search', filters.search);
      params.append('page', page.toString());
      params.append('limit', '12');

      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/api/cars?${params}`;
      const headers: HeadersInit = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const response = await fetch(apiUrl, { headers });
      const data = await response.json();

      setCars(data.cars || []);
      setTotalPages(data.pagination?.totalPages || 1);
    } catch (error) {
      console.error('Failed to fetch cars:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchCategories() {
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/api/categories`;
      const response = await fetch(apiUrl);
      const data = await response.json();
      setCategories(data.categories || []);
    } catch (error) {
      console.error('Failed to fetch categories:', error);
    }
  }

  function handleBookCar(car: Car) {
    setSelectedCar(car);
    setShowBookingModal(true);
  }

  function clearFilters() {
    setFilters({ category: '', status: '', minPrice: '', maxPrice: '', search: '' });
    setPage(1);
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              <button onClick={() => setSidebarOpen(!sidebarOpen)} className="lg:hidden p-2 rounded-md hover:bg-gray-100">
                {sidebarOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
              <h1 className="text-xl font-bold text-gray-900">AutoDrive Rentals</h1>
            </div>

            <nav className="hidden md:flex items-center gap-1">
              <button onClick={() => setActiveTab('browse')} className={`px-4 py-2 rounded-md font-medium ${activeTab === 'browse' ? 'bg-emerald-100 text-emerald-700' : 'text-gray-600 hover:bg-gray-100'}`}>
                Browse Cars
              </button>
              <button onClick={() => setActiveTab('rentals')} className={`px-4 py-2 rounded-md font-medium ${activeTab === 'rentals' ? 'bg-emerald-100 text-emerald-700' : 'text-gray-600 hover:bg-gray-100'}`}>
                My Rentals
              </button>
              {isAdmin && onAdminClick && (
                <button onClick={onAdminClick} className="px-4 py-2 rounded-md font-medium text-gray-600 hover:bg-gray-100 flex items-center gap-2">
                  <Shield className="h-4 w-4" />
                  Admin
                </button>
              )}
            </nav>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center">
                  <User className="h-4 w-4 text-white" />
                </div>
                <span className="hidden sm:block text-sm font-medium text-gray-700">{user?.full_name || user?.email}</span>
              </div>
              <button onClick={signOut} className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-md" title="Sign out">
                <LogOut className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className={`${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 fixed lg:static inset-y-0 left-0 z-30 w-64 bg-white border-r border-gray-200 lg:w-72 transition-transform lg:transition-none duration-300 ease-in-out`}>
          <div className="p-6 pt-20 lg:pt-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Filters</h2>

            {/* Mobile nav tabs */}
            <div className="mb-6 lg:hidden flex flex-col gap-2">
              <button onClick={() => { setActiveTab('browse'); setSidebarOpen(false); }} className={`w-full text-left px-4 py-2 rounded-md font-medium ${activeTab === 'browse' ? 'bg-emerald-100 text-emerald-700' : 'text-gray-600 hover:bg-gray-100'}`}>
                Browse Cars
              </button>
              <button onClick={() => { setActiveTab('rentals'); setSidebarOpen(false); }} className={`w-full text-left px-4 py-2 rounded-md font-medium ${activeTab === 'rentals' ? 'bg-emerald-100 text-emerald-700' : 'text-gray-600 hover:bg-gray-100'}`}>
                My Rentals
              </button>
              {isAdmin && onAdminClick && (
                <button onClick={() => { setSidebarOpen(false); onAdminClick(); }} className="w-full text-left px-4 py-2 rounded-md font-medium text-gray-600 hover:bg-gray-100 flex items-center gap-2">
                  <Shield className="h-4 w-4" />
                  Admin Panel
                </button>
              )}
            </div>

            <div className="space-y-4">
              {/* Search */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Search</label>
                <input type="text" value={filters.search} onChange={(e) => setFilters({ ...filters, search: e.target.value })} placeholder="Make or model..." className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500" />
              </div>

              {/* Category */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                <select value={filters.category} onChange={(e) => setFilters({ ...filters, category: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500">
                  <option value="">All Categories</option>
                  {categories.map((cat) => (
                    <option key={cat.id} value={cat.id}>{cat.name}</option>
                  ))}
                </select>
              </div>

              {/* Status */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                <select value={filters.status} onChange={(e) => setFilters({ ...filters, status: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500">
                  <option value="">All Status</option>
                  <option value="available">Available</option>
                  <option value="rented">Rented</option>
                  <option value="maintenance">Maintenance</option>
                </select>
              </div>

              {/* Price Range */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Min Price</label>
                  <input type="number" value={filters.minPrice} onChange={(e) => setFilters({ ...filters, minPrice: e.target.value })} placeholder="$0" className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Max Price</label>
                  <input type="number" value={filters.maxPrice} onChange={(e) => setFilters({ ...filters, maxPrice: e.target.value })} placeholder="$500" className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500" />
                </div>
              </div>

              <button onClick={clearFilters} className="w-full px-4 py-2 text-sm text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-md">
                Clear Filters
              </button>
            </div>

            {/* Stats */}
            <div className="mt-8 p-4 bg-emerald-50 rounded-lg">
              <p className="text-sm text-emerald-800 font-medium">Available: {cars.filter(c => c.status === 'available').length}</p>
              <p className="text-sm text-emerald-700 mt-1">{cars.length} vehicles shown</p>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-4 lg:p-8">
          {activeTab === 'browse' && (
            <>
              <div className="mb-6 flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-900">Available Vehicles</h2>
                <button onClick={() => setShowAddCarModal(true)} className="hidden md:flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 transition-colors">
                  <Plus className="h-4 w-4" />
                  Add Car
                </button>
              </div>

              {loading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[...Array(6)].map((_, i) => (
                    <div key={i} className="bg-white rounded-xl shadow-sm animate-pulse">
                      <div className="h-48 bg-gray-200 rounded-t-xl" />
                      <div className="p-5 space-y-3">
                        <div className="h-5 bg-gray-200 rounded w-3/4" />
                        <div className="h-4 bg-gray-200 rounded w-1/2" />
                        <div className="h-4 bg-gray-200 rounded w-1/4" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : cars.length === 0 ? (
                <div className="text-center py-16">
                  <CarIcon className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">No vehicles match your criteria</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {cars.map((car) => (
                    <div key={car.id} className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-lg transition-shadow">
                      <div className="relative h-48 bg-gray-100">
                        {car.image_url ? (
                          <img src={car.image_url} alt={`${car.make} ${car.model}`} className="w-full h-full object-cover" />
                        ) : (
                          <div className="flex items-center justify-center h-full">
                            <CarIcon className="h-16 w-16 text-gray-300" />
                          </div>
                        )}
                        <span className={`absolute top-3 right-3 px-3 py-1 text-xs font-medium rounded-full ${car.status === 'available' ? 'bg-emerald-100 text-emerald-700' : car.status === 'rented' ? 'bg-blue-100 text-blue-700' : 'bg-amber-100 text-amber-700'}`}>
                          {car.status.charAt(0).toUpperCase() + car.status.slice(1)}
                        </span>
                      </div>
                      <div className="p-5">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="text-lg font-semibold text-gray-900">{car.make} {car.model}</h3>
                          <span className="text-lg font-bold text-emerald-600">${car.daily_rate}<span className="text-sm font-normal text-gray-500">/day</span></span>
                        </div>
                        <p className="text-sm text-gray-600 mb-1">{car.year} • {car.category?.name || 'Uncategorized'}</p>
                        <p className="text-xs text-gray-500 mb-3">Plate: {car.license_plate}</p>
                        {car.features.length > 0 && (
                          <div className="flex flex-wrap gap-1 mb-4">
                            {car.features.slice(0, 3).map((feature, i) => (
                              <span key={i} className="px-2 py-0.5 text-xs bg-gray-100 text-gray-600 rounded">{feature}</span>
                            ))}
                            {car.features.length > 3 && (
                              <span className="px-2 py-0.5 text-xs bg-gray-100 text-gray-600 rounded">+{car.features.length - 3}</span>
                            )}
                          </div>
                        )}
                        <button onClick={() => handleBookCar(car)} disabled={car.status !== 'available'} className={`w-full py-2 rounded-md font-medium transition-colors ${car.status === 'available' ? 'bg-emerald-600 text-white hover:bg-emerald-700' : 'bg-gray-200 text-gray-500 cursor-not-allowed'}`}>
                          {car.status === 'available' ? 'Book Now' : 'Unavailable'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex justify-center gap-2 mt-8">
                  <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="px-4 py-2 rounded-md bg-white border border-gray-300 text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed">
                    Previous
                  </button>
                  <span className="px-4 py-2 text-sm text-gray-700">Page {page} of {totalPages}</span>
                  <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages} className="px-4 py-2 rounded-md bg-white border border-gray-300 text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed">
                    Next
                  </button>
                </div>
              )}
            </>
          )}

          {activeTab === 'rentals' && <MyRentalsPage token={token!} onAdminClick={onAdminClick} />}
        </main>
      </div>

      {/* Booking Modal */}
      {showBookingModal && selectedCar && (
        <BookingModal car={selectedCar} token={token!} onClose={() => setShowBookingModal(false)} />
      )}

      {/* Add Car Modal */}
      {showAddCarModal && (
        <AddCarModal categories={categories} token={token!} onClose={() => setShowAddCarModal(false)} onSave={fetchCars} />
      )}
    </div>
  );
}

// My Rentals Component
function MyRentalsPage({ token, onAdminClick }: { token: string; onAdminClick?: () => void }) {
  const [rentals, setRentals] = useState<unknown[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchRentals();
  }, [token]);

  async function fetchRentals() {
    setLoading(true);
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/api/rentals`;
      const response = await fetch(apiUrl, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
      setRentals(data.rentals || []);
    } catch (error) {
      console.error('Failed to fetch rentals:', error);
    } finally {
      setLoading(false);
    }
  }

  async function cancelRental(id: string) {
    if (!confirm('Are you sure you want to cancel this rental?')) return;

    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/api/rentals/${id}/cancel`;
      await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      fetchRentals();
    } catch (error) {
      console.error('Failed to cancel rental:', error);
    }
  }

  if (loading) {
    return <div className="animate-pulse space-y-4">
      {[...Array(3)].map((_, i) => (<div key={i} className="h-32 bg-gray-200 rounded-xl" />))}
    </div>;
  }

  const typedRentals = rentals as Array<{
    id: string;
    status: string;
    start_date: string;
    end_date: string;
    total_amount: number;
    pickup_location?: string;
    car: { make: string; model: string; year: number; image_url?: string; license_plate: string; daily_rate: number };
  }>;

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-900 mb-6">My Rentals</h2>

      {typedRentals.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-xl">
          <Calendar className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">No rentals yet. Browse cars to make your first booking!</p>
        </div>
      ) : (
        <div className="space-y-4">
          {typedRentals.map((rental) => (
            <div key={rental.id} className="bg-white rounded-xl shadow-sm p-5 flex gap-4">
              <div className="w-24 h-24 bg-gray-100 rounded-lg flex-shrink-0 overflow-hidden">
                {rental.car?.image_url ? (
                  <img src={rental.car.image_url} alt="" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <CarIcon className="h-8 w-8 text-gray-300" />
                  </div>
                )}
              </div>
              <div className="flex-1">
                <div className="flex justify-between">
                  <div>
                    <h3 className="font-semibold text-gray-900">{rental.car?.make} {rental.car?.model} ({rental.car?.year})</h3>
                    <p className="text-sm text-gray-600">Plate: {rental.car?.license_plate}</p>
                  </div>
                  <span className={`px-3 py-1 text-xs font-medium rounded-full h-fit ${rental.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                    rental.status === 'active' ? 'bg-blue-100 text-blue-700' :
                    rental.status === 'completed' ? 'bg-emerald-100 text-emerald-700' :
                    'bg-red-100 text-red-700'
                  }`}>
                    {rental.status.charAt(0).toUpperCase() + rental.status.slice(1)}
                  </span>
                </div>
                <div className="mt-2 flex gap-6 text-sm text-gray-600">
                  <span className="flex items-center gap-1"><Calendar className="h-4 w-4" /> {rental.start_date} - {rental.end_date}</span>
                  <span className="flex items-center gap-1"><CreditCard className="h-4 w-4" /> ${rental.total_amount}</span>
                </div>
                {rental.pickup_location && (
                  <p className="mt-1 text-sm text-gray-500 flex items-center gap-1">
                    <MapPin className="h-4 w-4" /> {rental.pickup_location}
                  </p>
                )}
                {(rental.status === 'pending' || rental.status === 'active') && (
                  <button onClick={() => cancelRental(rental.id)} className="mt-3 flex items-center gap-1 text-sm text-red-600 hover:text-red-700">
                    <XCircle className="h-4 w-4" /> Cancel Rental
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// Booking Modal Component
function BookingModal({ car, token, onClose }: { car: Car; token: string; onClose: () => void }) {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [pickupLocation, setPickupLocation] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const today = new Date().toISOString().split('T')[0];
  const total = startDate && endDate
    ? (Math.ceil((new Date(endDate).getTime() - new Date(startDate).getTime()) / (1000 * 60 * 60 * 24)) + 1) * car.daily_rate
    : 0;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/api/rentals`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          carId: car.id,
          startDate,
          endDate,
          pickupLocation,
        }),
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Booking failed');

      setSuccess(true);
      setTimeout(() => onClose(), 2000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Booking failed');
    } finally {
      setLoading(false);
    }
  }

  if (success) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-xl p-8 max-w-md w-full text-center">
          <CheckCircle className="h-16 w-16 text-emerald-500 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">Booking Confirmed!</h3>
          <p className="text-gray-600">Your rental has been booked successfully.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-md w-full p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold">Book {car.make} {car.model}</h3>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded-full">
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <div className="bg-gray-50 rounded-lg p-4 mb-4">
          <p className="text-sm text-gray-600">Daily Rate: <span className="font-semibold text-emerald-600">${car.daily_rate}</span></p>
          <p className="text-sm text-gray-600 mt-1">Category: {car.category?.name || 'N/A'}</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Pick-up Date</label>
            <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} min={today} required className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-emerald-500" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Return Date</label>
            <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} min={startDate || today} required className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-emerald-500" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Pick-up Location (Optional)</label>
            <input type="text" value={pickupLocation} onChange={(e) => setPickupLocation(e.target.value)} placeholder="e.g., Downtown Office" className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-emerald-500" />
          </div>

          {total > 0 && (
            <div className="bg-emerald-50 rounded-lg p-4">
              <p className="text-sm text-emerald-800">Estimated Total: <span className="text-2xl font-bold">${total.toLocaleString()}</span></p>
            </div>
          )}

          {error && (
            <p className="text-sm text-red-600 bg-red-50 p-2 rounded">{error}</p>
          )}

          <button type="submit" disabled={loading} className="w-full py-3 bg-emerald-600 text-white rounded-md font-medium hover:bg-emerald-700 disabled:opacity-50 transition-colors">
            {loading ? 'Processing...' : 'Confirm Booking'}
          </button>
        </form>
      </div>
    </div>
  );
}

// Add Car Modal Component
function AddCarModal({ categories, token, onClose, onSave }: { categories: Category[]; token: string; onClose: () => void; onSave: () => void }) {
  const [formData, setFormData] = useState({
    make: '',
    model: '',
    year: new Date().getFullYear(),
    licensePlate: '',
    categoryId: '',
    dailyRate: 50,
    status: 'available',
    features: '',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/api/cars`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          make: formData.make,
          model: formData.model,
          year: formData.year,
          licensePlate: formData.licensePlate,
          categoryId: formData.categoryId || null,
          dailyRate: formData.dailyRate,
          status: formData.status,
          features: formData.features.split(',').map(f => f.trim()).filter(Boolean),
        }),
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to add car');

      onSave();
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add car');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-md w-full p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold">Add New Vehicle</h3>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded-full">
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Make</label>
              <input type="text" value={formData.make} onChange={(e) => setFormData({ ...formData, make: e.target.value })} required className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-emerald-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Model</label>
              <input type="text" value={formData.model} onChange={(e) => setFormData({ ...formData, model: e.target.value })} required className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-emerald-500" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Year</label>
              <input type="number" value={formData.year} onChange={(e) => setFormData({ ...formData, year: parseInt(e.target.value) })} min="2000" max="2030" required className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-emerald-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">License Plate</label>
              <input type="text" value={formData.licensePlate} onChange={(e) => setFormData({ ...formData, licensePlate: e.target.value.toUpperCase() })} required placeholder="ABC-1234" className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-emerald-500" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
            <select value={formData.categoryId} onChange={(e) => setFormData({ ...formData, categoryId: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-emerald-500">
              <option value="">Select Category</option>
              {categories.map((cat) => (
                <option key={cat.id} value={cat.id}>{cat.name}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Daily Rate ($)</label>
              <input type="number" value={formData.dailyRate} onChange={(e) => setFormData({ ...formData, dailyRate: parseFloat(e.target.value) })} min="1" step="0.01" required className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-emerald-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
              <select value={formData.status} onChange={(e) => setFormData({ ...formData, status: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-emerald-500">
                <option value="available">Available</option>
                <option value="rented">Rented</option>
                <option value="maintenance">Maintenance</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Features (comma-separated)</label>
            <input type="text" value={formData.features} onChange={(e) => setFormData({ ...formData, features: e.target.value })} placeholder="Automatic, Bluetooth, GPS" className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-emerald-500" />
          </div>

          {error && <p className="text-sm text-red-600 bg-red-50 p-2 rounded">{error}</p>}

          <div className="flex gap-3">
            <button type="button" onClick={onClose} className="flex-1 py-2 border border-gray-300 rounded-md font-medium text-gray-700 hover:bg-gray-50">
              Cancel
            </button>
            <button type="submit" disabled={loading} className="flex-1 py-2 bg-emerald-600 text-white rounded-md font-medium hover:bg-emerald-700 disabled:opacity-50">
              {loading ? 'Adding...' : 'Add Vehicle'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
