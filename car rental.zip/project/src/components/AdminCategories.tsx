import { useState, useEffect } from 'react';
import { Tag, Plus, Edit, Trash2, X, AlertCircle } from 'lucide-react';

interface Category {
  id: string;
  name: string;
  description: string | null;
  base_daily_rate: number;
  created_at: string;
}

interface CategoryWithCount extends Category {
  carCount?: number;
}

export function AdminCategories() {
  const [categories, setCategories] = useState<CategoryWithCount[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [error, setError] = useState('');

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    baseDailyRate: 0,
  });

  useEffect(() => {
    fetchCategories();
  }, []);

  async function fetchCategories() {
    setLoading(true);
    const token = localStorage.getItem('token');
    if (!token) return;

    try {
      const baseUrl = import.meta.env.VITE_SUPABASE_URL;
      const [categoriesRes, carsRes] = await Promise.all([
        fetch(`${baseUrl}/functions/v1/api/categories`),
        fetch(`${baseUrl}/functions/v1/api/cars?limit=100`, {
          headers: { Authorization: `Bearer ${token}` }
        })
      ]);

      const categoriesData = await categoriesRes.json();
      const carsData = await carsRes.json();

      // Count cars per category
      const carCounts: Record<string, number> = {};
      (carsData.cars || []).forEach((car: { category_id: string }) => {
        carCounts[car.category_id] = (carCounts[car.category_id] || 0) + 1;
      });

      const categoriesWithCounts = (categoriesData.categories || []).map((cat: Category) => ({
        ...cat,
        carCount: carCounts[cat.id] || 0
      }));

      setCategories(categoriesWithCounts);
    } catch (error) {
      console.error('Failed to fetch categories:', error);
    } finally {
      setLoading(false);
    }
  }

  function openAddModal() {
    setEditingCategory(null);
    setFormData({ name: '', description: '', baseDailyRate: 0 });
    setError('');
    setShowModal(true);
  }

  function openEditModal(category: Category) {
    setEditingCategory(category);
    setFormData({
      name: category.name,
      description: category.description || '',
      baseDailyRate: category.base_daily_rate,
    });
    setError('');
    setShowModal(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    const token = localStorage.getItem('token');
    if (!token) return;

    const payload = {
      name: formData.name,
      description: formData.description || null,
      baseDailyRate: formData.baseDailyRate,
    };

    try {
      const baseUrl = import.meta.env.VITE_SUPABASE_URL;
      const url = editingCategory
        ? `${baseUrl}/functions/v1/api/categories/${editingCategory.id}`
        : `${baseUrl}/functions/v1/api/categories`;

      const response = await fetch(url, {
        method: editingCategory ? 'PUT' : 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Operation failed');

      setShowModal(false);
      fetchCategories();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Operation failed');
    }
  }

  async function deleteCategory(category: Category) {
    if (!confirm(`Delete "${category.name}" category?`)) return;

    const token = localStorage.getItem('token');
    if (!token) return;

    try {
      const baseUrl = import.meta.env.VITE_SUPABASE_URL;
      const response = await fetch(`${baseUrl}/functions/v1/api/categories/${category.id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to delete');
      }

      fetchCategories();
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Cannot delete category with existing cars');
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <p className="text-gray-600">Manage vehicle categories and base pricing</p>
        <button
          onClick={openAddModal}
          className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors"
        >
          <Plus className="h-4 w-4" />
          Add Category
        </button>
      </div>

      {/* Categories Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-white rounded-xl shadow-sm p-6 animate-pulse">
              <div className="h-5 bg-gray-200 rounded w-24 mb-3" />
              <div className="h-4 bg-gray-200 rounded w-full" />
            </div>
          ))}
        </div>
      ) : categories.length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm p-12 text-center">
          <Tag className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">No categories yet</p>
          <button onClick={openAddModal} className="mt-4 text-emerald-600 hover:text-emerald-700 font-medium">
            Add your first category
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {categories.map((category) => (
            <div key={category.id} className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                  <Tag className="h-6 w-6 text-emerald-600" />
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => openEditModal(category)}
                    className="p-2 text-gray-500 hover:bg-gray-100 rounded-lg"
                    title="Edit"
                  >
                    <Edit className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => deleteCategory(category)}
                    className="p-2 text-red-500 hover:bg-red-50 rounded-lg"
                    title="Delete"
                    disabled={category.carCount && category.carCount > 0}
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>

              <h3 className="text-lg font-semibold text-gray-900">{category.name}</h3>
              {category.description && (
                <p className="text-sm text-gray-500 mt-1 line-clamp-2">{category.description}</p>
              )}

              <div className="mt-4 pt-4 border-t border-gray-100 flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-500">Base Rate</p>
                  <p className="text-lg font-bold text-emerald-600">${category.base_daily_rate}/day</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-gray-500">Vehicles</p>
                  <p className="text-lg font-semibold text-gray-900">{category.carCount || 0}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-semibold">
                {editingCategory ? 'Edit Category' : 'Add New Category'}
              </h3>
              <button onClick={() => setShowModal(false)} className="p-1 hover:bg-gray-100 rounded-full">
                <X className="h-5 w-5 text-gray-500" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  placeholder="e.g., Economy, SUV, Luxury"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={3}
                  placeholder="Brief description of this category..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 resize-none"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Base Daily Rate ($)</label>
                <input
                  type="number"
                  value={formData.baseDailyRate}
                  onChange={(e) => setFormData({ ...formData, baseDailyRate: parseFloat(e.target.value) || 0 })}
                  min="0"
                  step="0.01"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
                />
                <p className="text-xs text-gray-500 mt-1">Suggested minimum daily rate for this category</p>
              </div>

              {error && (
                <div className="bg-red-50 text-red-600 text-sm p-3 rounded-lg flex items-center gap-2">
                  <AlertCircle className="h-4 w-4" />
                  {error}
                </div>
              )}

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 py-2 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-emerald-600 text-white rounded-lg font-medium hover:bg-emerald-700"
                >
                  {editingCategory ? 'Update Category' : 'Add Category'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}