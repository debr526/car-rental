import { useState, useEffect } from 'react';
import { useAuth, AuthProvider } from './hooks/useAuth';
import { AuthPage } from './components/AuthPage';
import { CarsPage } from './components/CarsPage';
import { AdminPanel } from './components/AdminPage';

function AppContent() {
  const { user, loading } = useAuth();
  const [initialLoading, setInitialLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'customer' | 'admin'>('customer');

  useEffect(() => {
    // Give time for auth state to restore from localStorage
    const timer = setTimeout(() => {
      setInitialLoading(false);
    }, 100);
    return () => clearTimeout(timer);
  }, []);

  // Check URL path on mount
  useEffect(() => {
    const path = window.location.pathname;
    if (path.includes('/admin')) {
      setViewMode('admin');
    }
  }, []);

  if (initialLoading || loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-slate-100 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-emerald-600 rounded-2xl mb-4 shadow-lg shadow-emerald-600/30 animate-pulse">
            <svg className="h-8 w-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
            </svg>
          </div>
          <p className="text-gray-600">Loading QuickReserve...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthPage onAuth={() => {}} />;
  }

  // If on admin path, show admin panel
  if (viewMode === 'admin' || window.location.pathname.includes('/admin')) {
    return <AdminPanel />;
  }

  return <CarsPage onAdminClick={() => {
    setViewMode('admin');
    window.history.pushState({}, '', '/admin/dashboard');
  }} />;
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;