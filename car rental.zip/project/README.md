# QuickReserve - Car Rental System

A full-stack car rental management system built with modern web technologies, featuring secure authentication, role-based access control, and a complete RESTful API.

## Project Overview

QuickReserve is a comprehensive car rental platform that allows customers to browse available vehicles, make reservations, and manage their rentals. Administrators have full control over the vehicle fleet, bookings, users, and categories through a dedicated admin dashboard.

### Key Features

- **User Authentication**: Secure signup/login with Supabase Auth (JWT-based sessions)
- **Role-Based Access Control (RBAC)**: Admin and Customer roles with different permissions
- **Vehicle Management**: Browse, filter, and search cars by category, price, and availability
- **Rental System**: Book vehicles with date selection, automatic pricing, and status tracking
- **Admin Dashboard**: Complete admin interface with statistics and management tools
- **Responsive Design**: Mobile-first UI with beautiful animations

## Default Admin Account

For testing and demonstration, a default admin account is pre-configured:

- **Email**: admin@quickreserve.com
- **Password**: Admin123
- **Role**: admin

This account has full admin privileges to access the admin dashboard at `/admin/dashboard`.

## Technology Stack

### Frontend
- **React 18** - UI library with hooks
- **TypeScript** - Type-safe development
- **Tailwind CSS** - Utility-first styling
- **Vite** - Fast build tool and dev server
- **Lucide React** - Modern icon library

### Backend
- **Supabase Edge Functions** - Serverless API (Deno runtime)
- **Express.js-style routing** - MVC architecture pattern
- **PostgreSQL** - Relational database (via Supabase)

### Security
- **JWT Authentication** - Token-based session management
- **Row Level Security (RLS)** - Database-level access control
- **BCrypt-style hashing** - Secure password storage (via Supabase Auth)
- **CORS Protection** - Configured for secure API access

## Architecture

### MVC Pattern Implementation

```
project/
├── backend/src/           # Backend MVC Structure
│   ├── models/            # Data access layer
│   │   ├── user.js       # User data operations
│   │   ├── car.js        # Car CRUD operations
│   │   ├── rental.js     # Rental transactions
│   │   └── category.js   # Category management
│   ├── controllers/      # Business logic
│   │   ├── auth.controller.js
│   │   ├── cars.controller.js
│   │   ├── rentals.controller.js
│   │   └── categories.controller.js
│   ├── routes/           # API endpoints
│   ├── middleware/       # Auth, validation, logging
│   │   ├── auth.js      # JWT verification
│   │   ├── validation.js # Input sanitization
│   │   └── errorHandler.js
│   └── config/           # Database & app config
│
├── supabase/functions/api/  # Deployed serverless API
│   └── index.ts          # Edge function entry point
│
└── src/                  # React Frontend
    ├── components/       # UI Components
    ├── hooks/            # Custom hooks (useAuth)
    └── lib/              # API client
```

## Database Schema

### Entity-Relationship Diagram

```
┌──────────────────┐       ┌──────────────────┐
│     profiles     │       │    categories    │
├──────────────────┤       ├──────────────────┤
│ id (PK)          │       │ id (PK)          │
│ email (UNIQUE)   │       │ name (UNIQUE)    │
│ full_name        │       │ description      │
│ role             │       │ base_daily_rate  │
│ phone            │       │ created_at       │
│ created_at       │       └────────┬─────────┘
└────────┬─────────┘                │
         │                          │ 1:N
         │                          │
         │        ┌─────────────────┴──────────────────┐
         │        │                cars                  │
         │        ├──────────────────────────────────────┤
         │        │ id (PK)                              │
         │        │ make                                 │
         │        │ model                                │
         │        │ year                                 │
         │        │ license_plate (UNIQUE)               │
         │        │ category_id (FK) ────────────────────┘
         │        │ daily_rate                           │
         │        │ status (available|rented|maintenance)│
         │        │ image_url                            │
         │        │ features (array)                     │
         │        │ created_at                           │
         │        └──────────────┬───────────────────────┘
         │                       │
         │ 1:N                   │ N:1
         │                       │
┌────────┴─────────────────────┐ │
│           rentals             │ │
├───────────────────────────────┤ │
│ id (PK)                       │ │
│ car_id (FK) ──────────────────┼─┘
│ user_id (FK) ─────────────────┤
│ start_date                    │
│ end_date                      │
│ total_amount                  │
│ status (pending|active|       │
│        completed|cancelled)   │
│ pickup_location               │
│ return_location               │
│ notes                         │
│ created_at                    │
│ updated_at                    │
└───────────────────────────────┘

Foreign Keys:
- cars.category_id → categories.id (ON DELETE SET NULL)
- rentals.car_id → cars.id (ON DELETE RESTRICT)
- rentals.user_id → profiles.id (ON DELETE CASCADE)
- profiles.id → auth.users.id (ON DELETE CASCADE)
```

### DDL (Data Definition Language)

```sql
-- Profiles table (extends Supabase auth.users)
CREATE TABLE profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  full_name text,
  role text NOT NULL DEFAULT 'customer' CHECK (role IN ('admin', 'customer')),
  phone text,
  created_at timestamptz DEFAULT now()
);

-- Categories table
CREATE TABLE categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  description text,
  base_daily_rate numeric(10,2) NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Cars table
CREATE TABLE cars (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  make text NOT NULL,
  model text NOT NULL,
  year integer NOT NULL CHECK (year >= 1900 AND year <= EXTRACT(year FROM now()) + 1),
  license_plate text UNIQUE NOT NULL,
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  daily_rate numeric(10,2) NOT NULL CHECK (daily_rate >= 0),
  status text NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'rented', 'maintenance')),
  image_url text,
  features text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Rentals table
CREATE TABLE rentals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  car_id uuid NOT NULL REFERENCES cars(id) ON DELETE RESTRICT,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  start_date date NOT NULL,
  end_date date NOT NULL,
  total_amount numeric(10,2) NOT NULL CHECK (total_amount >= 0),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'completed', 'cancelled')),
  pickup_location text,
  return_location text,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CHECK (end_date >= start_date)
);

-- Indexes for performance
CREATE INDEX idx_cars_status ON cars(status);
CREATE INDEX idx_cars_category ON cars(category_id);
CREATE INDEX idx_rentals_user ON rentals(user_id);
CREATE INDEX idx_rentals_car ON rentals(car_id);
CREATE INDEX idx_rentals_status ON rentals(status);
CREATE INDEX idx_rentals_dates ON rentals(start_date, end_date);
```

## RESTful API Endpoints

### Authentication

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/auth/signup` | Create new account |
| POST | `/auth/login` | Authenticate user |
| POST | `/auth/logout` | Sign out user |
| GET | `/auth/me` | Get current user |

### Cars

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/cars` | Optional | List all cars (with filters) |
| GET | `/cars/:id` | Optional | Get car details |
| POST | `/cars` | Admin | Add new vehicle |
| PUT | `/cars/:id` | Admin | Update vehicle |
| DELETE | `/cars/:id` | Admin | Remove vehicle |

### Rentals

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/rentals` | Required | List user's rentals |
| GET | `/rentals/:id` | Required | Get rental details |
| POST | `/rentals` | Required | Create booking |
| PUT | `/rentals/:id` | Required | Update rental |
| POST | `/rentals/:id/cancel` | Required | Cancel rental |

### Categories

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/categories` | Public | List categories |
| POST | `/categories` | Admin | Create category |
| PUT | `/categories/:id` | Admin | Update category |
| DELETE | `/categories/:id` | Admin | Delete category |

### Query Parameters

**Cars filtering:**
- `category` - Filter by category ID
- `status` - Filter by status (available/rented/maintenance)
- `minPrice`, `maxPrice` - Price range
- `search` - Search make/model
- `page`, `limit` - Pagination

## Setup and Installation

### Prerequisites

- Node.js 18+ installed
- Supabase account (project already provisioned in this environment)

### Environment Variables

The following variables are pre-configured in `.env`:

```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_anon_key
SUPABASE_URL=your_supabase_url
SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
SUPABASE_DB_URL=your_database_url
```

### Installation Steps

```bash
# 1. Install dependencies
npm install

# 2. Start development server (runs automatically in this environment)
npm run dev

# 3. Build for production
npm run build
```

### Creating an Admin User

**Using the default admin account:**
- Email: admin@quickreserve.com
- Password: Admin123
- This account is created automatically during database setup

**Creating additional admins:**
1. Sign up through the application normally (creates a 'customer' role)
2. In Supabase dashboard, go to Table Editor → profiles
3. Change the user's `role` from 'customer' to 'admin'

## Admin Dashboard

Access the admin panel at `/admin/dashboard`. The dashboard includes:

### Dashboard
- Total number of cars
- Total registered users
- Total bookings
- Pending, active, and completed bookings count
- Total revenue

### Manage Cars
- View all cars with filtering
- Add new vehicles
- Edit car information
- Delete cars
- Update availability status (available/rented/maintenance)

### Manage Bookings
- View all customer reservations
- View detailed booking information
- Approve pending bookings
- Reject bookings
- Mark active rentals as completed
- Cancel bookings

### Manage Users
- View all registered users
- View customer information
- Change user roles (customer ↔ admin)

### Manage Categories
- View categories
- Add categories
- Edit categories
- Delete categories

## Security Implementation

### Authentication Flow

1. User signs up/logs in via Supabase Auth
2. JWT token returned and stored in localStorage
3. Token included in Authorization header for API requests
4. Edge function validates token with Supabase

### Authorization (RBAC)

- **Customer Role**: Can view cars, manage own rentals
- **Admin Role**: Full CRUD on cars, categories; view all rentals

### Row Level Security (RLS)

Every table has RLS enabled with policies:

```sql
-- Example: Users can only see their own rentals
CREATE POLICY "rentals_read" ON rentals FOR SELECT
  TO authenticated USING (
    auth.uid() = user_id OR EXISTS (
      SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
    )
  );
```

### Password Security

Passwords are hashed using Supabase's built-in bcrypt implementation. No plain-text passwords are ever stored.

## Features Beyond Course Scope

1. **Serverless Architecture**: Edge Functions instead of traditional server
2. **Real-time Updates**: Supabase real-time subscriptions (ready to enable)
3. **Type Safety**: Full TypeScript implementation
4. **Automatic Profile Creation**: Database trigger creates profile on signup
7. **Responsive Design**: Mobile-first with breakpoints
8. **Loading States**: Skeleton screens for better UX
9. **Error Handling**: Comprehensive error boundaries and messaging

## License

MIT License - Feel free to use this project for learning and development.

---

Built with modern web technologies for the Car Rental System project.
