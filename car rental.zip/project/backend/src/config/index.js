export const config = {
  jwt: {
    secret: Deno.env.get('JWT_SECRET') || 'your-secret-key-change-in-production',
    expiresIn: '7d'
  },
  app: {
    name: 'Car Rentals API',
    version: '1.0.0',
    environment: Deno.env.get('DENO_DEPLOYMENT_ID') ? 'production' : 'development'
  }
};

export default config;
