import { AuthController } from '../controllers/index.js';
import { authenticateToken } from '../middleware/index.js';

export function setupAuthRoutes(router) {
  // Public routes
  router.post('/signup', AuthController.signup);
  router.post('/login', AuthController.login);
  router.post('/refresh-token', AuthController.refreshToken);

  // Protected routes
  router.post('/logout', AuthController.logout);
  router.get('/me', authenticateToken, AuthController.me);

  return router;
}

export default setupAuthRoutes;
