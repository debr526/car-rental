import { CategoryController } from '../controllers/index.js';
import { authenticateToken, requireAdmin, optionalAuth } from '../middleware/index.js';

export function setupCategoryRoutes(router) {
  // Public routes
  router.get('/', optionalAuth, CategoryController.getAll);
  router.get('/:id', optionalAuth, CategoryController.getById);

  // Admin routes
  router.post('/', authenticateToken, requireAdmin, CategoryController.create);
  router.put('/:id', authenticateToken, requireAdmin, CategoryController.update);
  router.delete('/:id', authenticateToken, requireAdmin, CategoryController.delete);

  return router;
}

export default setupCategoryRoutes;
