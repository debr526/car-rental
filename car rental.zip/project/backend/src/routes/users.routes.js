import { UserController } from '../controllers/index.js';
import { authenticateToken, requireAdmin } from '../middleware/index.js';

export function setupUserRoutes(router) {
  // Protected routes - authenticated users
  router.get('/profile', authenticateToken, UserController.getProfile);
  router.put('/profile', authenticateToken, UserController.updateProfile);

  // Admin routes
  router.get('/', authenticateToken, requireAdmin, UserController.getAll);
  router.post('/:id/admin', authenticateToken, requireAdmin, UserController.makeAdmin);

  return router;
}

export default setupUserRoutes;
