import { RentalController } from '../controllers/index.js';
import { authenticateToken } from '../middleware/index.js';

export function setupRentalRoutes(router) {
  // All routes require authentication
  router.get('/', authenticateToken, RentalController.getAll);
  router.get('/stats', authenticateToken, RentalController.getStats);
  router.post('/', authenticateToken, RentalController.create);
  router.get('/:id', authenticateToken, RentalController.getById);
  router.put('/:id', authenticateToken, RentalController.update);
  router.post('/:id/cancel', authenticateToken, RentalController.cancel);

  return router;
}

export default setupRentalRoutes;
