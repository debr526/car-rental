import { setupAuthRoutes } from './auth.routes.js';
import { setupUserRoutes } from './users.routes.js';
import { setupCarRoutes } from './cars.routes.js';
import { setupRentalRoutes } from './rentals.routes.js';
import { setupCategoryRoutes } from './categories.routes.js';

export {
  setupAuthRoutes,
  setupUserRoutes,
  setupCarRoutes,
  setupRentalRoutes,
  setupCategoryRoutes
};

export default {
  setupAuthRoutes,
  setupUserRoutes,
  setupCarRoutes,
  setupRentalRoutes,
  setupCategoryRoutes
};
