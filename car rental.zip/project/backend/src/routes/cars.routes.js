import { CarController } from '../controllers/index.js';
import { authenticateToken, requireAdmin, optionalAuth } from '../middleware/index.js';

export function setupCarRoutes(router) {
  // Public routes
  router.get('/', optionalAuth, CarController.getAll);
  router.get('/:id', optionalAuth, CarController.getById);
  router.get('/:id/availability', optionalAuth, CarController.checkAvailability);

  // Admin routes
  router.post('/', authenticateToken, requireAdmin, CarController.create);
  router.put('/:id', authenticateToken, requireAdmin, CarController.update);
  router.delete('/:id', authenticateToken, requireAdmin, CarController.delete);

  return router;
}

export default setupCarRoutes;
