const validator = {
  email: (value) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!value) return 'Email is required';
    if (!emailRegex.test(value)) return 'Invalid email format';
    return null;
  },

  password: (value) => {
    if (!value) return 'Password is required';
    if (value.length < 6) return 'Password must be at least 6 characters';
    return null;
  },

  required: (value, fieldName) => {
    if (value === undefined || value === null || value === '') {
      return `${fieldName} is required`;
    }
    return null;
  },

  minLength: (value, min, fieldName) => {
    if (!value || value.length < min) {
      return `${fieldName} must be at least ${min} characters`;
    }
    return null;
  },

  maxLength: (value, max, fieldName) => {
    if (value && value.length > max) {
      return `${fieldName} must be at most ${max} characters`;
    }
    return null;
  },

  min: (value, min, fieldName) => {
    if (value === undefined || value === null || parseFloat(value) < min) {
      return `${fieldName} must be at least ${min}`;
    }
    return null;
  },

  max: (value, max, fieldName) => {
    if (value !== undefined && value !== null && parseFloat(value) > max) {
      return `${fieldName} must be at most ${max}`;
    }
    return null;
  },

  in: (value, allowedValues, fieldName) => {
    if (value && !allowedValues.includes(value)) {
      return `Invalid ${fieldName}. Must be one of: ${allowedValues.join(', ')}`;
    }
    return null;
  },

  date: (value, fieldName) => {
    if (!value) return `${fieldName} is required`;
    const date = new Date(value);
    if (isNaN(date.getTime())) return `Invalid ${fieldName} format`;
    return null;
  },

  futureDate: (value, fieldName) => {
    const error = validator.date(value, fieldName);
    if (error) return error;

    const date = new Date(value);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (date < today) {
      return `${fieldName} must be in the future`;
    }
    return null;
  }
};

export function validateRequest(rules, source = 'body') {
  return async (req, res, next) => {
    const errors = [];
    const data = source === 'body' ? req.body : source === 'query' ? req.query : req.params;

    for (const [field, fieldRules] of Object.entries(rules)) {
      const value = data[field];

      for (const rule of fieldRules) {
        let error = null;

        if (typeof rule === 'string') {
          // Simple rule name
          if (rule === 'required') {
            error = validator.required(value, field);
          } else if (rule === 'email') {
            error = validator.email(value);
          } else if (rule === 'password') {
            error = validator.password(value);
          } else if (rule === 'date') {
            error = validator.date(value, field);
          } else if (rule === 'futureDate') {
            error = validator.futureDate(value, field);
          }
        } else if (typeof rule === 'object') {
          // Rule with parameters
          const { type, ...params } = rule;
          switch (type) {
            case 'minLength':
              error = validator.minLength(value, params.value, field);
              break;
            case 'maxLength':
              error = validator.maxLength(value, params.value, field);
              break;
            case 'min':
              error = validator.min(value, params.value, field);
              break;
            case 'max':
              error = validator.max(value, params.value, field);
              break;
            case 'in':
              error = validator.in(value, params.values, field);
              break;
          }
        } else if (typeof rule === 'function') {
          // Custom validator function
          error = rule(value, data);
        }

        if (error) {
          errors.push({ field, message: error });
          break; // Stop checking more rules for this field
        }
      }
    }

    if (errors.length > 0) {
      return res.status(400).json({
        error: 'Validation failed',
        details: errors
      });
    }

    next();
  };
}

export default { validateRequest, validator };
