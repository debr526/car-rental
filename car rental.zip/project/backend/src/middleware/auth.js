import { createClient } from '@supabase/supabase-js';
import logger from '../utils/logger.js';

const supabaseUrl = Deno.env.get('SUPABASE_URL');
const supabaseKey = Deno.env.get('SUPABASE_ANON_KEY');

const supabaseClient = createClient(supabaseUrl, supabaseKey);

export async function authenticateToken(req, res, next) {
  const authHeader = req.headers.get('authorization');
  const token = authHeader?.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  try {
    const { data: { user }, error } = await supabaseClient.auth.getUser(token);

    if (error || !user) {
      logger.warn('Invalid token used', { error: error?.message });
      return res.status(401).json({ error: 'Invalid or expired token' });
    }

    // Attach user to request
    req.user = {
      id: user.id,
      email: user.email
    };

    next();
  } catch (error) {
    logger.error('Authentication error', { error: error.message });
    return res.status(401).json({ error: 'Authentication failed' });
  }
}

export async function requireAdmin(req, res, next) {
  const { User } = await import('../models/user.js');

  try {
    const user = await User.findById(req.user.id);

    if (!user || user.role !== 'admin') {
      return res.status(403).json({ error: 'Admin access required' });
    }

    req.user.role = user.role;
    next();
  } catch (error) {
    logger.error('Authorization error', { error: error.message });
    return res.status(500).json({ error: 'Authorization check failed' });
  }
}

export async function optionalAuth(req, res, next) {
  const authHeader = req.headers.get('authorization');
  const token = authHeader?.split(' ')[1];

  if (!token) {
    return next();
  }

  try {
    const { data: { user }, error } = await supabaseClient.auth.getUser(token);

    if (!error && user) {
      req.user = {
        id: user.id,
        email: user.email
      };
    }
  } catch (error) {
    // Silent fail for optional auth
    logger.debug('Optional auth failed', { error: error.message });
  }

  next();
}

export default {
  authenticateToken,
  requireAdmin,
  optionalAuth
};
