import logger from '../utils/logger.js';

export function errorHandler(err, req, res, next) {
  logger.error('Unhandled error', {
    error: err.message,
    stack: err.stack,
    path: req.path,
    method: req.method
  });

  // PostgreSQL/SUPABASE errors
  if (err.code) {
    switch (err.code) {
      case '23505': // Unique violation
        return res.status(409).json({
          error: 'Resource already exists',
          message: err.detail || 'This record already exists'
        });
      case '23503': // Foreign key violation
        return res.status(400).json({
          error: 'Invalid reference',
          message: 'Referenced resource does not exist'
        });
      case '23502': // Not null violation
        return res.status(400).json({
          error: 'Missing required field',
          message: err.detail || 'A required field is missing'
        });
    }
  }

  // Application errors
  if (err.status) {
    return res.status(err.status).json({
      error: err.message
    });
  }

  // Default error
  return res.status(500).json({
    error: 'Internal server error'
  });
}

export function notFound(req, res) {
  res.status(404).json({ error: 'Resource not found' });
}

export default { errorHandler, notFound };
