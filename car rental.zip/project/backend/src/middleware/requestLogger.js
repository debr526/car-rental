const requestLogger = (req, res, next) => {
  const start = Date.now();

  // Capture response finish
  const originalEnd = res.end;
  res.end = function(chunk, encoding) {
    const duration = Date.now() - start;
    res.end = originalEnd;
    res.end(chunk, encoding);

    const meta = {
      method: req.method,
      path: req.path,
      status: res.statusCode,
      duration: `${duration}ms`
    };

    // Log response status
    if (res.statusCode >= 400) {
      console.warn('[API]', meta);
    } else {
      console.info('[API]', meta);
    }
  };

  next();
};

export default requestLogger;
