import supabase from '../config/database.js';

export class User {
  static async findById(id) {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) throw error;
    return data;
  }

  static async findByEmail(email) {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('email', email)
      .maybeSingle();

    if (error) throw error;
    return data;
  }

  static async create(userData) {
    const { data, error } = await supabase
      .from('profiles')
      .insert([userData])
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  static async update(id, updates) {
    const { data, error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  static async getAll(page = 1, limit = 10) {
    const offset = (page - 1) * limit;

    const [usersResult, countResult] = await Promise.all([
      supabase
        .from('profiles')
        .select('id, email, full_name, role, phone, created_at')
        .order('created_at', { ascending: false })
        .range(offset, offset + limit - 1),
      supabase
        .from('profiles')
        .select('id', { count: 'exact', head: true })
    ]);

    if (usersResult.error) throw usersResult.error;
    if (countResult.error) throw countResult.error;

    return {
      users: usersResult.data,
      total: countResult.count
    };
  }
}

export default User;
