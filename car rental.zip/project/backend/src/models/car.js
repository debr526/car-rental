import supabase from '../config/database.js';

export class Car {
  static async findAll(filters = {}, page = 1, limit = 10) {
    const offset = (page - 1) * limit;
    let query = supabase
      .from('cars')
      .select(`
        *,
        category:categories(id, name)
      `)
      .order('created_at', { ascending: false });

    // Apply filters
    if (filters.category) {
      query = query.eq('category_id', filters.category);
    }
    if (filters.status) {
      query = query.eq('status', filters.status);
    }
    if (filters.minPrice) {
      query = query.gte('daily_rate', filters.minPrice);
    }
    if (filters.maxPrice) {
      query = query.lte('daily_rate', filters.maxPrice);
    }
    if (filters.make) {
      query = query.ilike('make', `%${filters.make}%`);
    }
    if (filters.search) {
      query = query.or(`make.ilike.%${filters.search}%,model.ilike.%${filters.search}%`);
    }

    // Get total count
    const countQuery = supabase
      .from('cars')
      .select('id', { count: 'exact', head: true });

    // Apply same filters to count
    if (filters.category) countQuery.eq('category_id', filters.category);
    if (filters.status) countQuery.eq('status', filters.status);
    if (filters.minPrice) countQuery.gte('daily_rate', filters.minPrice);
    if (filters.maxPrice) countQuery.lte('daily_rate', filters.maxPrice);
    if (filters.make) countQuery.ilike('make', `%${filters.make}%`);
    if (filters.search) countQuery.or(`make.ilike.%${filters.search}%,model.ilike.%${filters.search}%`);

    const [carsResult, countResult] = await Promise.all([
      query.range(offset, offset + limit - 1),
      countQuery
    ]);

    if (carsResult.error) throw carsResult.error;
    if (countResult.error) throw countResult.error;

    return {
      cars: carsResult.data,
      total: countResult.count
    };
  }

  static async findById(id) {
    const { data, error } = await supabase
      .from('cars')
      .select(`
        *,
        category:categories(id, name, description)
      `)
      .eq('id', id)
      .maybeSingle();

    if (error) throw error;
    return data;
  }

  static async create(carData) {
    const { data, error } = await supabase
      .from('cars')
      .insert([carData])
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  static async update(id, updates) {
    const { data, error } = await supabase
      .from('cars')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  static async delete(id) {
    const { error } = await supabase
      .from('cars')
      .delete()
      .eq('id', id);

    if (error) throw error;
    return true;
  }

  static async getAvailableForDates(startDate, endDate, filters = {}) {
    let query = supabase
      .from('cars')
      .select(`
        *,
        category:categories(id, name)
      `)
      .eq('status', 'available');

    // Apply additional filters
    if (filters.category) {
      query = query.eq('category_id', filters.category);
    }
    if (filters.minPrice) {
      query = query.gte('daily_rate', filters.minPrice);
    }
    if (filters.maxPrice) {
      query = query.lte('daily_rate', filters.maxPrice);
    }

    const { data, error } = await query;

    if (error) throw error;

    // Exclude cars that have overlapping rentals
    const { data: overlappingRentals, error: rentalError } = await supabase
      .from('rentals')
      .select('car_id')
      .not('status', 'eq', 'cancelled')
      .or(`and(start_date.lte.${endDate},end_date.gte.${startDate})`);

    if (rentalError) throw rentalError;

    const bookedCarIds = new Set(overlappingRentals?.map(r => r.car_id) || []);
    return data.filter(car => !bookedCarIds.has(car.id));
  }
}

export default Car;
