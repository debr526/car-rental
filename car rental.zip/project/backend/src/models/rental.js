import supabase from '../config/database.js';

export class Rental {
  static async findAll(filters = {}, page = 1, limit = 10) {
    const offset = (page - 1) * limit;
    let query = supabase
      .from('rentals')
      .select(`
        *,
        car:cars(id, make, model, year, license_plate, image_url, daily_rate),
        user:profiles(id, email, full_name)
      `)
      .order('created_at', { ascending: false });

    // Apply filters
    if (filters.userId) {
      query = query.eq('user_id', filters.userId);
    }
    if (filters.carId) {
      query = query.eq('car_id', filters.carId);
    }
    if (filters.status) {
      query = query.eq('status', filters.status);
    }
    if (filters.startDate) {
      query = query.gte('start_date', filters.startDate);
    }
    if (filters.endDate) {
      query = query.lte('end_date', filters.endDate);
    }

    // Get total count with same filters
    const countQuery = supabase
      .from('rentals')
      .select('id', { count: 'exact', head: true });

    if (filters.userId) countQuery.eq('user_id', filters.userId);
    if (filters.carId) countQuery.eq('car_id', filters.carId);
    if (filters.status) countQuery.eq('status', filters.status);
    if (filters.startDate) countQuery.gte('start_date', filters.startDate);
    if (filters.endDate) countQuery.lte('end_date', filters.endDate);

    const [rentalsResult, countResult] = await Promise.all([
      query.range(offset, offset + limit - 1),
      countQuery
    ]);

    if (rentalsResult.error) throw rentalsResult.error;
    if (countResult.error) throw countResult.error;

    return {
      rentals: rentalsResult.data,
      total: countResult.count
    };
  }

  static async findById(id) {
    const { data, error } = await supabase
      .from('rentals')
      .select(`
        *,
        car:cars(id, make, model, year, license_plate, image_url, daily_rate, category_id,
          category:categories(id, name)
        ),
        user:profiles(id, email, full_name, phone)
      `)
      .eq('id', id)
      .maybeSingle();

    if (error) throw error;
    return data;
  }

  static async create(rentalData) {
    const { data, error } = await supabase
      .from('rentals')
      .insert([rentalData])
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  static async update(id, updates) {
    const { data, error } = await supabase
      .from('rentals')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  static async delete(id) {
    const { error } = await supabase
      .from('rentals')
      .delete()
      .eq('id', id);

    if (error) throw error;
    return true;
  }

  static async checkAvailability(carId, startDate, endDate, excludeRentalId = null) {
    let query = supabase
      .from('rentals')
      .select('id')
      .eq('car_id', carId)
      .not('status', 'eq', 'cancelled')
      .or(`and(start_date.lte.${endDate},end_date.gte.${startDate})`);

    if (excludeRentalId) {
      query = query.neq('id', excludeRentalId);
    }

    const { data, error } = await query;

    if (error) throw error;
    return data?.length === 0;
  }

  static async getStats(userId = null) {
    let rentalsQuery = supabase
      .from('rentals')
      .select('id, status, total_amount');

    if (userId) {
      rentalsQuery = rentalsQuery.eq('user_id', userId);
    }

    const { data, error } = await rentalsQuery;

    if (error) throw error;

    return {
      total: data?.length || 0,
      pending: data?.filter(r => r.status === 'pending').length || 0,
      active: data?.filter(r => r.status === 'active').length || 0,
      completed: data?.filter(r => r.status === 'completed').length || 0,
      cancelled: data?.filter(r => r.status === 'cancelled').length || 0,
      totalRevenue: data?.reduce((sum, r) => sum + (parseFloat(r.total_amount) || 0), 0) || 0
    };
  }
}

export default Rental;
