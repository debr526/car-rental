const LOG_LEVELS = {
  ERROR: 0,
  WARN: 1,
  INFO: 2,
  DEBUG: 3
};

const currentLevel = LOG_LEVELS.INFO;

function formatLogEntry(level, message, meta = {}) {
  return {
    timestamp: new Date().toISOString(),
    level,
    message,
    ...meta
  };
}

export const logger = {
  error: (message, meta = {}) => {
    if (currentLevel >= LOG_LEVELS.ERROR) {
      console.error(JSON.stringify(formatLogEntry('ERROR', message, meta)));
    }
  },
  warn: (message, meta = {}) => {
    if (currentLevel >= LOG_LEVELS.WARN) {
      console.warn(JSON.stringify(formatLogEntry('WARN', message, meta)));
    }
  },
  info: (message, meta = {}) => {
    if (currentLevel >= LOG_LEVELS.INFO) {
      console.info(JSON.stringify(formatLogEntry('INFO', message, meta)));
    }
  },
  debug: (message, meta = {}) => {
    if (currentLevel >= LOG_LEVELS.DEBUG) {
      console.debug(JSON.stringify(formatLogEntry('DEBUG', message, meta)));
    }
  },
  request: (req, res, duration) => {
    logger.info('HTTP Request', {
      method: req.method,
      path: req.path,
      status: res.status,
      duration: `${duration}ms`,
      userAgent: req.headers.get('user-agent')
    });
  }
};

export default logger;
