import { Category } from '../models/index.js';
import logger from '../utils/logger.js';

export class CategoryController {
  static async getAll(req, res) {
    try {
      const categories = await Category.findAll();
      return res.json({ categories });
    } catch (error) {
      logger.error('Get categories error', { error: error.message });
      return res.status(500).json({ error: 'Failed to get categories' });
    }
  }

  static async getById(req, res) {
    try {
      const { id } = req.params;
      const category = await Category.findById(id);

      if (!category) {
        return res.status(404).json({ error: 'Category not found' });
      }

      return res.json({ category });
    } catch (error) {
      logger.error('Get category error', { error: error.message });
      return res.status(500).json({ error: 'Failed to get category' });
    }
  }

  static async create(req, res) {
    try {
      const { name, description, baseDailyRate } = req.body;

      const categoryData = {
        name,
        description,
        base_daily_rate: baseDailyRate || 0
      };

      const category = await Category.create(categoryData);

      logger.info('Category created', { categoryId: category.id, name });

      return res.status(201).json({ category });
    } catch (error) {
      logger.error('Create category error', { error: error.message });

      if (error.code === '23505') {
        return res.status(409).json({ error: 'Category name already exists' });
      }

      return res.status(500).json({ error: 'Failed to create category' });
    }
  }

  static async update(req, res) {
    try {
      const { id } = req.params;
      const { name, description, baseDailyRate } = req.body;

      const updates = {};
      if (name !== undefined) updates.name = name;
      if (description !== undefined) updates.description = description;
      if (baseDailyRate !== undefined) updates.base_daily_rate = baseDailyRate;

      if (Object.keys(updates).length === 0) {
        return res.status(400).json({ error: 'No fields to update' });
      }

      const category = await Category.update(id, updates);

      logger.info('Category updated', { categoryId: id });

      return res.json({ category });
    } catch (error) {
      logger.error('Update category error', { error: error.message });

      if (error.code === '23505') {
        return res.status(409).json({ error: 'Category name already exists' });
      }

      return res.status(500).json({ error: 'Failed to update category' });
    }
  }

  static async delete(req, res) {
    try {
      const { id } = req.params;
      await Category.delete(id);

      logger.info('Category deleted', { categoryId: id });

      return res.json({ message: 'Category deleted successfully' });
    } catch (error) {
      logger.error('Delete category error', { error: error.message });

      if (error.code === '23503') {
        return res.status(400).json({ error: 'Cannot delete category with existing cars' });
      }

      return res.status(500).json({ error: 'Failed to delete category' });
    }
  }
}

export default CategoryController;
