import { Car } from '../models/index.js';
import logger from '../utils/logger.js';

export class CarController {
  static async getAll(req, res) {
    try {
      const page = parseInt(req.query.page) || 1;
      const limit = parseInt(req.query.limit) || 12;

      const filters = {
        category: req.query.category,
        status: req.query.status,
        minPrice: req.query.minPrice ? parseFloat(req.query.minPrice) : undefined,
        maxPrice: req.query.maxPrice ? parseFloat(req.query.maxPrice) : undefined,
        make: req.query.make,
        search: req.query.search
      };

      // Remove undefined filters
      Object.keys(filters).forEach(key => {
        if (filters[key] === undefined) delete filters[key];
      });

      const { cars, total } = await Car.findAll(filters, page, limit);

      return res.json({
        cars,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit)
        }
      });
    } catch (error) {
      logger.error('Get all cars error', { error: error.message });
      return res.status(500).json({ error: 'Failed to get cars' });
    }
  }

  static async getById(req, res) {
    try {
      const { id } = req.params;

      const car = await Car.findById(id);

      if (!car) {
        return res.status(404).json({ error: 'Car not found' });
      }

      return res.json({ car });
    } catch (error) {
      logger.error('Get car error', { error: error.message });
      return res.status(500).json({ error: 'Failed to get car' });
    }
  }

  static async create(req, res) {
    try {
      const { make, model, year, licensePlate, categoryId, dailyRate, status, imageUrl, features } = req.body;

      const carData = {
        make,
        model,
        year,
        license_plate: licensePlate,
        category_id: categoryId,
        daily_rate: dailyRate,
        status: status || 'available',
        image_url: imageUrl,
        features: features || []
      };

      const car = await Car.create(carData);

      logger.info('Car created', { carId: car.id, plate: licensePlate });

      return res.status(201).json({ car });
    } catch (error) {
      logger.error('Create car error', { error: error.message });

      if (error.code === '23505') {
        return res.status(409).json({ error: 'License plate already exists' });
      }

      return res.status(500).json({ error: 'Failed to create car' });
    }
  }

  static async update(req, res) {
    try {
      const { id } = req.params;

      const allowedFields = ['make', 'model', 'year', 'license_plate', 'category_id', 'daily_rate', 'status', 'image_url', 'features'];
      const updates = {};
      // Map camelCase to snake_case where needed
      const mapping = {
        'category_id': 'category_id',
        'daily_rate': 'daily_rate',
        'license_plate': 'license_plate',
        'image_url': 'image_url'
      };

      for (const [key, value] of Object.entries(req.body)) {
        const dbKey = mapping[key] || key;
        if (allowedFields.includes(dbKey)) {
          // Handle camelCase to snake_case conversion for request keys
          const field = mapping[key] || (allowedFields.includes(key) ? key : null);
          if (field) {
            updates[field] = value;
          }
        }
      }

      if (Object.keys(updates).length === 0) {
        return res.status(400).json({ error: 'No fields to update' });
      }

      const car = await Car.update(id, updates);

      logger.info('Car updated', { carId: id });

      return res.json({ car });
    } catch (error) {
      logger.error('Update car error', { error: error.message });

      if (error.code === '23505') {
        return res.status(409).json({ error: 'License plate already exists' });
      }

      return res.status(500).json({ error: 'Failed to update car' });
    }
  }

  static async delete(req, res) {
    try {
      const { id } = req.params;

      await Car.delete(id);

      logger.info('Car deleted', { carId: id });

      return res.json({ message: 'Car deleted successfully' });
    } catch (error) {
      logger.error('Delete car error', { error: error.message });

      if (error.code === '23503') {
        return res.status(400).json({ error: 'Cannot delete car with existing rentals' });
      }

      return res.status(500).json({ error: 'Failed to delete car' });
    }
  }

  static async checkAvailability(req, res) {
    try {
      const { id } = req.params;
      const { startDate, endDate } = req.query;

      const car = await Car.findById(id);
      if (!car) {
        return res.status(404).json({ error: 'Car not found' });
      }

      if (car.status !== 'available') {
        return res.json({
          available: false,
          reason: `Car is currently ${car.status}`
        });
      }

      return res.json({ available: true });
    } catch (error) {
      logger.error('Check availability error', { error: error.message });
      return res.status(500).json({ error: 'Failed to check availability' });
    }
  }
}

export default CarController;
