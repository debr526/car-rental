import { Rental, Car } from '../models/index.js';
import logger from '../utils/logger.js';

function calculateTotalPrice(rate, startDate, endDate) {
  const start = new Date(startDate);
  const end = new Date(endDate);
  const days = Math.ceil((end - start) / (1000 * 60 * 60 * 24)) + 1;
  return days * rate;
}

export class RentalController {
  static async getAll(req, res) {
    try {
      const page = parseInt(req.query.page) || 1;
      const limit = parseInt(req.query.limit) || 12;

      const filters = {};

      // Admin can see all, customers can only see their own
      if (req.user.role !== 'admin') {
        filters.userId = req.user.id;
      } else {
        if (req.query.userId) {
          filters.userId = req.query.userId;
        }
      }

      if (req.query.carId) filters.carId = req.query.carId;
      if (req.query.status) filters.status = req.query.status;
      if (req.query.startDate) filters.startDate = req.query.startDate;
      if (req.query.endDate) filters.endDate = req.query.endDate;

      const { rentals, total } = await Rental.findAll(filters, page, limit);

      return res.json({
        rentals,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit)
        }
      });
    } catch (error) {
      logger.error('Get all rentals error', { error: error.message });
      return res.status(500).json({ error: 'Failed to get rentals' });
    }
  }

  static async getById(req, res) {
    try {
      const { id } = req.params;

      const rental = await Rental.findById(id);

      if (!rental) {
        return res.status(404).json({ error: 'Rental not found' });
      }

      // Check authorization - user can only access their own rentals
      if (req.user.role !== 'admin' && rental.user_id !== req.user.id) {
        return res.status(403).json({ error: 'Access denied' });
      }

      return res.json({ rental });
    } catch (error) {
      logger.error('Get rental error', { error: error.message });
      return res.status(500).json({ error: 'Failed to get rental' });
    }
  }

  static async create(req, res) {
    try {
      const { carId, startDate, endDate, pickupLocation, returnLocation, notes } = req.body;

      // Get car details
      const car = await Car.findById(carId);
      if (!car) {
        return res.status(404).json({ error: 'Car not found' });
      }

      if (car.status !== 'available') {
        return res.status(400).json({ error: 'Car is not available for rental' });
      }

      // Check availability
      const available = await Rental.checkAvailability(carId, startDate, endDate);
      if (!available) {
        return res.status(400).json({ error: 'Car is not available for the selected dates' });
      }

      // Calculate total price
      const totalAmount = calculateTotalPrice(car.daily_rate, startDate, endDate);

      const rentalData = {
        car_id: carId,
        user_id: req.user.id,
        start_date: startDate,
        end_date: endDate,
        total_amount: totalAmount,
        status: 'pending',
        pickup_location: pickupLocation,
        return_location: returnLocation,
        notes
      };

      const rental = await Rental.create(rentalData);

      logger.info('Rental created', { rentalId: rental.id, carId, userId: req.user.id });

      return res.status(201).json({ rental });
    } catch (error) {
      logger.error('Create rental error', { error: error.message });
      return res.status(500).json({ error: 'Failed to create rental' });
    }
  }

  static async update(req, res) {
    try {
      const { id } = req.params;

      const rental = await Rental.findById(id);
      if (!rental) {
        return res.status(404).json({ error: 'Rental not found' });
      }

      // Check authorization
      if (req.user.role !== 'admin' && rental.user_id !== req.user.id) {
        return res.status(403).json({ error: 'Access denied' });
      }

      const allowedUpdates = ['startDate', 'endDate', 'status', 'pickupLocation', 'returnLocation', 'notes'];
      const updates = {};

      for (const [key, value] of Object.entries(req.body)) {
        if (allowedUpdates.includes(key)) {
          const dbKey = key === 'startDate' ? 'start_date' :
                        key === 'endDate' ? 'end_date' :
                        key === 'pickupLocation' ? 'pickup_location' :
                        key === 'returnLocation' ? 'return_location' :
                        key;
          updates[dbKey] = value;
        }
      }

      // Validate status values
      const validStatuses = ['pending', 'active', 'completed', 'cancelled'];
      if (updates.status && !validStatuses.includes(updates.status)) {
        return res.status(400).json({ error: 'Invalid status value' });
      }

      // Recalculate price if dates changed
      if (updates.start_date || updates.end_date) {
        const startDate = updates.start_date || rental.start_date;
        const endDate = updates.end_date || rental.end_date;

        // Check availability for new dates
        const available = await Rental.checkAvailability(
          rental.car_id,
          startDate,
          endDate,
          id
        );

        if (!available) {
          return res.status(400).json({ error: 'Car is not available for the selected dates' });
        }

        updates.total_amount = calculateTotalPrice(rental.car.daily_rate, startDate, endDate);
      }

      const updatedRental = await Rental.update(id, updates);

      logger.info('Rental updated', { rentalId: id, userId: req.user.id });

      return res.json({ rental: updatedRental });
    } catch (error) {
      logger.error('Update rental error', { error: error.message });
      return res.status(500).json({ error: 'Failed to update rental' });
    }
  }

  static async cancel(req, res) {
    try {
      const { id } = req.params;

      const rental = await Rental.findById(id);
      if (!rental) {
        return res.status(404).json({ error: 'Rental not found' });
      }

      // Check authorization
      if (req.user.role !== 'admin' && rental.user_id !== req.user.id) {
        return res.status(403).json({ error: 'Access denied' });
      }

      // Only pending rentals can be cancelled by customers
      if (rental.status !== 'pending' && rental.status !== 'active') {
        return res.status(400).json({
          error: 'Only pending or active rentals can be cancelled'
        });
      }

      // Update car status to available
      await Car.update(rental.car_id, { status: 'available' });

      // Update rental status
      const updatedRental = await Rental.update(id, { status: 'cancelled' });

      logger.info('Rental cancelled', { rentalId: id, userId: req.user.id });

      return res.json({ rental: updatedRental });
    } catch (error) {
      logger.error('Cancel rental error', { error: error.message });
      return res.status(500).json({ error: 'Failed to cancel rental' });
    }
  }

  static async getStats(req, res) {
    try {
      // Admin gets all stats, customers get their own
      const userId = req.user.role === 'admin' ? null : req.user.id;
      const stats = await Rental.getStats(userId);

      return res.json({ stats });
    } catch (error) {
      logger.error('Get rental stats error', { error: error.message });
      return res.status(500).json({ error: 'Failed to get stats' });
    }
  }
}

export default RentalController;
