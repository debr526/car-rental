import { User } from '../models/index.js';
import logger from '../utils/logger.js';

export class UserController {
  static async getProfile(req, res) {
    try {
      const user = await User.findById(req.user.id);

      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      return res.json({ user });
    } catch (error) {
      logger.error('Get profile error', { error: error.message });
      return res.status(500).json({ error: 'Failed to get profile' });
    }
  }

  static async updateProfile(req, res) {
    try {
      const { fullName, phone } = req.body;

      const updates = {};
      if (fullName !== undefined) updates.full_name = fullName;
      if (phone !== undefined) updates.phone = phone;

      if (Object.keys(updates).length === 0) {
        return res.status(400).json({ error: 'No fields to update' });
      }

      const user = await User.update(req.user.id, updates);

      logger.info('Profile updated', { userId: req.user.id });

      return res.json({ user });
    } catch (error) {
      logger.error('Update profile error', { error: error.message });
      return res.status(500).json({ error: 'Failed to update profile' });
    }
  }

  static async getAll(req, res) {
    try {
      const page = parseInt(req.query.page) || 1;
      const limit = parseInt(req.query.limit) || 10;

      const { users, total } = await User.getAll(page, limit);

      return res.json({
        users,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit)
        }
      });
    } catch (error) {
      logger.error('Get all users error', { error: error.message });
      return res.status(500).json({ error: 'Failed to get users' });
    }
  }

  static async makeAdmin(req, res) {
    try {
      const { id } = req.params;

      const user = await User.update(id, { role: 'admin' });

      logger.info('User promoted to admin', { userId: id, promotedBy: req.user.id });

      return res.json({ user, message: 'User promoted to admin' });
    } catch (error) {
      logger.error('Make admin error', { error: error.message });
      return res.status(500).json({ error: 'Failed to promote user' });
    }
  }
}

export default UserController;
