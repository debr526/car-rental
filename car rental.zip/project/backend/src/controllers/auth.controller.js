import { createClient } from '@supabase/supabase-js';
import logger from '../utils/logger.js';

const supabaseUrl = Deno.env.get('SUPABASE_URL');
const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY');

const supabase = createClient(supabaseUrl, supabaseAnonKey);

export class AuthController {
  static async signup(req, res) {
    try {
      const { email, password, fullName, phone } = req.body;

      if (!email || !password) {
        return res.status(400).json({ error: 'Email and password are required' });
      }

      if (password.length < 6) {
        return res.status(400).json({ error: 'Password must be at least 6 characters' });
      }

      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName || 'User',
            phone
          },
          emailRedirectTo: undefined // Disable email confirmation
        }
      });

      if (error) {
        logger.warn('Signup failed', { email, error: error.message });
        return res.status(400).json({ error: error.message });
      }

      logger.info('User signed up', { userId: data.user?.id, email });

      return res.status(201).json({
        message: 'User created successfully',
        user: {
          id: data.user?.id,
          email: data.user?.email
        },
        session: data.session ? {
          access_token: data.session.access_token,
          refresh_token: data.session.refresh_token,
          expires_at: data.session.expires_at
        } : null
      });
    } catch (error) {
      logger.error('Signup error', { error: error.message });
      return res.status(500).json({ error: 'Failed to create user' });
    }
  }

  static async login(req, res) {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        return res.status(400).json({ error: 'Email and password are required' });
      }

      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) {
        logger.warn('Login failed', { email, error: error.message });
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      logger.info('User logged in', { userId: data.user?.id, email });

      return res.json({
        message: 'Login successful',
        user: {
          id: data.user.id,
          email: data.user.email
        },
        session: {
          access_token: data.session.access_token,
          refresh_token: data.session.refresh_token,
          expires_at: data.session.expires_at
        }
      });
    } catch (error) {
      logger.error('Login error', { error: error.message });
      return res.status(500).json({ error: 'Failed to login' });
    }
  }

  static async logout(req, res) {
    try {
      const authHeader = req.headers.get('authorization');
      const token = authHeader?.split(' ')[1];

      if (token) {
        await supabase.auth.signOut();
      }

      logger.info('User logged out');
      return res.json({ message: 'Logged out successfully' });
    } catch (error) {
      logger.error('Logout error', { error: error.message });
      return res.status(500).json({ error: 'Failed to logout' });
    }
  }

  static async me(req, res) {
    try {
      // User is already attached by middleware
      if (!req.user) {
        return res.status(401).json({ error: 'Not authenticated' });
      }

      return res.json({
        user: req.user
      });
    } catch (error) {
      logger.error('Get current user error', { error: error.message });
      return res.status(500).json({ error: 'Failed to get user info' });
    }
  }

  static async refreshToken(req, res) {
    try {
      const { refreshToken } = req.body;

      if (!refreshToken) {
        return res.status(400).json({ error: 'Refresh token is required' });
      }

      const { data, error } = await supabase.auth.refreshSession({
        refresh_token: refreshToken
      });

      if (error) {
        return res.status(401).json({ error: 'Invalid refresh token' });
      }

      return res.json({
        session: {
          access_token: data.session.access_token,
          refresh_token: data.session.refresh_token,
          expires_at: data.session.expires_at
        }
      });
    } catch (error) {
      logger.error('Token refresh error', { error: error.message });
      return res.status(500).json({ error: 'Failed to refresh token' });
    }
  }
}

export default AuthController;
