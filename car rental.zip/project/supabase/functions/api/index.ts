import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

// Simple request context helper
function createResponse(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" }
  });
}

// Error response helper
function errorResponse(message: string, status = 400) {
  return new Response(JSON.stringify({ error: message }), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" }
  });
}

// Parse request body
async function parseBody(req: Request) {
  try {
    return await req.json();
  } catch {
    return {};
  }
}

// Import Supabase client
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY')!;

const supabase = createClient(supabaseUrl, supabaseKey);
const supabaseClient = createClient(supabaseUrl, supabaseAnonKey);

// Auth middleware
async function getUser(req: Request) {
  const authHeader = req.headers.get('authorization');
  const token = authHeader?.split(' ')[1];

  if (!token) return null;

  const { data: { user } } = await supabaseClient.auth.getUser(token);
  return user;
}

// Check if user is admin
async function requireAdmin(userId: string) {
  const { data: profile } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', userId)
    .single();

  return profile?.role === 'admin';
}

// Log requests
function log(method: string, path: string, status: number) {
  console.log(`[API] ${method} ${path} - ${status}`);
}

Deno.serve(async (req: Request) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  const url = new URL(req.url);
  const method = req.method;
  const path = url.pathname.replace('/functions/v1/api', '');
  const query = Object.fromEntries(url.searchParams);

  try {
    // ==================== AUTH ROUTES ====================
    if (path === '/auth/signup' && method === 'POST') {
      const body = await parseBody(req);
      const { email, password, fullName, phone } = body;

      if (!email || !password) {
        log(method, path, 400);
        return errorResponse('Email and password are required');
      }

      const { data, error } = await supabaseClient.auth.signUp({
        email,
        password,
        options: {
          data: { full_name: fullName || 'User', phone }
        }
      });

      if (error) {
        log(method, path, 400);
        return errorResponse(error.message);
      }

      log(method, path, 201);
      return createResponse({
        message: 'User created successfully',
        user: { id: data.user?.id, email: data.user?.email },
        session: data.session ? {
          access_token: data.session.access_token,
          refresh_token: data.session.refresh_token,
          expires_at: data.session.expires_at
        } : null
      }, 201);
    }

    if (path === '/auth/login' && method === 'POST') {
      const body = await parseBody(req);
      const { email, password } = body;

      if (!email || !password) {
        log(method, path, 400);
        return errorResponse('Email and password are required');
      }

      const { data, error } = await supabaseClient.auth.signInWithPassword({
        email,
        password
      });

      if (error) {
        log(method, path, 401);
        return errorResponse('Invalid credentials', 401);
      }

      log(method, path, 200);
      return createResponse({
        message: 'Login successful',
        user: { id: data.user.id, email: data.user.email },
        session: {
          access_token: data.session.access_token,
          refresh_token: data.session.refresh_token,
          expires_at: data.session.expires_at
        }
      });
    }

    if (path === '/auth/me' && method === 'GET') {
      const user = await getUser(req);
      if (!user) {
        log(method, path, 401);
        return errorResponse('Not authenticated', 401);
      }

      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      log(method, path, 200);
      return createResponse({ user: profile });
    }

    // ==================== CARS ROUTES ====================
    if (path === '/cars' && method === 'GET') {
      const page = parseInt(query.page) || 1;
      const limit = parseInt(query.limit) || 12;
      const offset = (page - 1) * limit;

      let dbQuery = supabase
        .from('cars')
        .select('*, category:categories(id, name)', { count: 'exact' })
        .order('created_at', { ascending: false });

      // Apply filters
      if (query.category) dbQuery = dbQuery.eq('category_id', query.category);
      if (query.status) dbQuery = dbQuery.eq('status', query.status);
      if (query.minPrice) dbQuery = dbQuery.gte('daily_rate', parseFloat(query.minPrice));
      if (query.maxPrice) dbQuery = dbQuery.lte('daily_rate', parseFloat(query.maxPrice));
      if (query.search) {
        dbQuery = dbQuery.or(`make.ilike.%${query.search}%,model.ilike.%${query.search}%`);
      }

      const { data, error, count } = await dbQuery.range(offset, offset + limit - 1);

      if (error) {
        log(method, path, 500);
        return errorResponse(error.message, 500);
      }

      log(method, path, 200);
      return createResponse({
        cars: data,
        pagination: { page, limit, total: count, totalPages: Math.ceil(count! / limit) }
      });
    }

    if (path.match(/^\/cars\/[a-f0-9-]+$/) && method === 'GET') {
      const id = path.split('/')[2];
      const { data, error } = await supabase
        .from('cars')
        .select('*, category:categories(id, name, description)')
        .eq('id', id)
        .single();

      if (error || !data) {
        log(method, path, 404);
        return errorResponse('Car not found', 404);
      }

      log(method, path, 200);
      return createResponse({ car: data });
    }

    // Admin: create car
    if (path === '/cars' && method === 'POST') {
      const user = await getUser(req);
      if (!user) {
        log(method, path, 401);
        return errorResponse('Not authenticated', 401);
      }

      const isAdmin = await requireAdmin(user.id);
      if (!isAdmin) {
        log(method, path, 403);
        return errorResponse('Admin access required', 403);
      }

      const body = await parseBody(req);
      const carData = {
        make: body.make,
        model: body.model,
        year: body.year,
        license_plate: body.licensePlate,
        category_id: body.categoryId,
        daily_rate: body.dailyRate,
        status: body.status || 'available',
        image_url: body.imageUrl,
        features: body.features || []
      };

      const { data, error } = await supabase
        .from('cars')
        .insert([carData])
        .select()
        .single();

      if (error) {
        log(method, path, 400);
        return errorResponse(error.code === '23505' ? 'License plate already exists' : error.message);
      }

      log(method, path, 201);
      return createResponse({ car: data }, 201);
    }

    // Admin: update car
    if (path.match(/^\/cars\/[a-f0-9-]+$/) && method === 'PUT') {
      const user = await getUser(req);
      if (!user) {
        log(method, path, 401);
        return errorResponse('Not authenticated', 401);
      }

      const isAdmin = await requireAdmin(user.id);
      if (!isAdmin) {
        log(method, path, 403);
        return errorResponse('Admin access required', 403);
      }

      const id = path.split('/')[2];
      const body = await parseBody(req);

      const updates: Record<string, unknown> = {};
      const mapping: Record<string, string> = {
        make: 'make',
        model: 'model',
        year: 'year',
        licensePlate: 'license_plate',
        categoryId: 'category_id',
        dailyRate: 'daily_rate',
        status: 'status',
        imageUrl: 'image_url',
        features: 'features'
      };

      for (const [key, value] of Object.entries(body)) {
        if (mapping[key]) {
          updates[mapping[key]] = value;
        }
      }

      const { data, error } = await supabase
        .from('cars')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) {
        log(method, path, 400);
        return errorResponse(error.message);
      }

      log(method, path, 200);
      return createResponse({ car: data });
    }

    // Admin: delete car
    if (path.match(/^\/cars\/[a-f0-9-]+$/) && method === 'DELETE') {
      const user = await getUser(req);
      if (!user) {
        log(method, path, 401);
        return errorResponse('Not authenticated', 401);
      }

      const isAdmin = await requireAdmin(user.id);
      if (!isAdmin) {
        log(method, path, 403);
        return errorResponse('Admin access required', 403);
      }

      const id = path.split('/')[2];
      const { error } = await supabase.from('cars').delete().eq('id', id);

      if (error) {
        log(method, path, 400);
        return errorResponse(error.message);
      }

      log(method, path, 200);
      return createResponse({ message: 'Car deleted successfully' });
    }

    // ==================== CATEGORIES ROUTES ====================
    if (path === '/categories' && method === 'GET') {
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .order('name');

      if (error) {
        log(method, path, 500);
        return errorResponse(error.message, 500);
      }

      log(method, path, 200);
      return createResponse({ categories: data });
    }

    // Admin: create category
    if (path === '/categories' && method === 'POST') {
      const user = await getUser(req);
      if (!user) {
        log(method, path, 401);
        return errorResponse('Not authenticated', 401);
      }

      const isAdmin = await requireAdmin(user.id);
      if (!isAdmin) {
        log(method, path, 403);
        return errorResponse('Admin access required', 403);
      }

      const body = await parseBody(req);
      const { data, error } = await supabase
        .from('categories')
        .insert([{
          name: body.name,
          description: body.description,
          base_daily_rate: body.baseDailyRate || 0
        }])
        .select()
        .single();

      if (error) {
        log(method, path, 400);
        return errorResponse(error.message);
      }

      log(method, path, 201);
      return createResponse({ category: data }, 201);
    }

    // ==================== RENTALS ROUTES ====================
    if (path === '/rentals' && method === 'GET') {
      const user = await getUser(req);
      if (!user) {
        log(method, path, 401);
        return errorResponse('Not authenticated', 401);
      }

      const page = parseInt(query.page) || 1;
      const limit = parseInt(query.limit) || 12;
      const offset = (page - 1) * limit;

      // Check if admin
      const isAdmin = await requireAdmin(user.id);

      let dbQuery = supabase
        .from('rentals')
        .select(`
          *,
          car:cars(id, make, model, year, license_plate, image_url, daily_rate),
          user:profiles(id, email, full_name)
        `, { count: 'exact' })
        .order('created_at', { ascending: false });

      // Non-admins only see their own rentals
      if (!isAdmin) {
        dbQuery = dbQuery.eq('user_id', user.id);
      } else if (query.userId) {
        dbQuery = dbQuery.eq('user_id', query.userId);
      }

      if (query.status) dbQuery = dbQuery.eq('status', query.status);

      const { data, error, count } = await dbQuery.range(offset, offset + limit - 1);

      if (error) {
        log(method, path, 500);
        return errorResponse(error.message, 500);
      }

      log(method, path, 200);
      return createResponse({
        rentals: data,
        pagination: { page, limit, total: count, totalPages: Math.ceil(count! / limit) }
      });
    }

    if (path === '/rentals' && method === 'POST') {
      const user = await getUser(req);
      if (!user) {
        log(method, path, 401);
        return errorResponse('Not authenticated', 401);
      }

      const body = await parseBody(req);
      const { carId, startDate, endDate, pickupLocation, returnLocation, notes } = body;

      // Get car details
      const { data: car } = await supabase
        .from('cars')
        .select('*')
        .eq('id', carId)
        .single();

      if (!car) {
        log(method, path, 404);
        return errorResponse('Car not found', 404);
      }

      if (car.status !== 'available') {
        log(method, path, 400);
        return errorResponse('Car is not available for rental');
      }

      // Check for overlapping rentals
      const { data: overlapping } = await supabase
        .from('rentals')
        .select('id')
        .eq('car_id', carId)
        .neq('status', 'cancelled')
        .or(`and(start_date.lte.${endDate},end_date.gte.${startDate})`);

      if (overlapping && overlapping.length > 0) {
        log(method, path, 400);
        return errorResponse('Car is not available for the selected dates');
      }

      // Calculate total
      const start = new Date(startDate);
      const end = new Date(endDate);
      const days = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1;
      const total_amount = days * car.daily_rate;

      const { data, error } = await supabase
        .from('rentals')
        .insert([{
          car_id: carId,
          user_id: user.id,
          start_date: startDate,
          end_date: endDate,
          total_amount,
          pickup_location: pickupLocation,
          return_location: returnLocation,
          notes
        }])
        .select()
        .single();

      if (error) {
        log(method, path, 500);
        return errorResponse(error.message, 500);
      }

      log(method, path, 201);
      return createResponse({ rental: data }, 201);
    }

    if (path.match(/^\/rentals\/[a-f0-9-]+$/) && method === 'GET') {
      const user = await getUser(req);
      if (!user) {
        log(method, path, 401);
        return errorResponse('Not authenticated', 401);
      }

      const id = path.split('/')[2];
      const isAdmin = await requireAdmin(user.id);

      const { data, error } = await supabase
        .from('rentals')
        .select(`
          *,
          car:cars(id, make, model, year, license_plate, image_url, daily_rate,
            category:categories(id, name)),
          user:profiles(id, email, full_name, phone)
        `)
        .eq('id', id)
        .single();

      if (error || !data) {
        log(method, path, 404);
        return errorResponse('Rental not found', 404);
      }

      // Check authorization
      if (!isAdmin && data.user_id !== user.id) {
        log(method, path, 403);
        return errorResponse('Access denied', 403);
      }

      log(method, path, 200);
      return createResponse({ rental: data });
    }

    // Cancel rental
    if (path.match(/^\/rentals\/[a-f0-9-]+\/cancel$/) && method === 'POST') {
      const user = await getUser(req);
      if (!user) {
        log(method, path, 401);
        return errorResponse('Not authenticated', 401);
      }

      const id = path.split('/')[2];
      const isAdmin = await requireAdmin(user.id);

      const { data: rental } = await supabase
        .from('rentals')
        .select('*')
        .eq('id', id)
        .single();

      if (!rental) {
        log(method, path, 404);
        return errorResponse('Rental not found', 404);
      }

      // Check authorization
      if (!isAdmin && rental.user_id !== user.id) {
        log(method, path, 403);
        return errorResponse('Access denied', 403);
      }

      if (rental.status !== 'pending' && rental.status !== 'active') {
        log(method, path, 400);
        return errorResponse('Only pending or active rentals can be cancelled');
      }

      // Update car status and rental status
      await supabase.from('cars').update({ status: 'available' }).eq('id', rental.car_id);
      const { data, error } = await supabase
        .from('rentals')
        .update({ status: 'cancelled' })
        .eq('id', id)
        .select()
        .single();

      if (error) {
        log(method, path, 500);
        return errorResponse(error.message, 500);
      }

      log(method, path, 200);
      return createResponse({ rental: data });
    }

    // Update rental status (admin)
    if (path.match(/^\/rentals\/[a-f0-9-]+$/) && method === 'PUT') {
      const user = await getUser(req);
      if (!user) {
        log(method, path, 401);
        return errorResponse('Not authenticated', 401);
      }

      const id = path.split('/')[2];
      const isAdmin = await requireAdmin(user.id);

      const { data: rental } = await supabase
        .from('rentals')
        .select('*')
        .eq('id', id)
        .single();

      if (!rental) {
        log(method, path, 404);
        return errorResponse('Rental not found', 404);
      }

      // Check authorization
      if (!isAdmin && rental.user_id !== user.id) {
        log(method, path, 403);
        return errorResponse('Access denied', 403);
      }

      const body = await parseBody(req);
      const validStatuses = ['pending', 'active', 'completed', 'cancelled'];

      if (body.status && !validStatuses.includes(body.status)) {
        log(method, path, 400);
        return errorResponse('Invalid status value');
      }

      const { data, error } = await supabase
        .from('rentals')
        .update({ status: body.status })
        .eq('id', id)
        .select()
        .single();

      if (error) {
        log(method, path, 500);
        return errorResponse(error.message, 500);
      }

      log(method, path, 200);
      return createResponse({ rental: data });
    }

    // Get rental stats
    if (path === '/rentals/stats' && method === 'GET') {
      const user = await getUser(req);
      if (!user) {
        log(method, path, 401);
        return errorResponse('Not authenticated', 401);
      }

      const isAdmin = await requireAdmin(user.id);

      let dbQuery = supabase.from('rentals').select('id, status, total_amount');
      if (!isAdmin) {
        dbQuery = dbQuery.eq('user_id', user.id);
      }

      const { data } = await dbQuery;

      const stats = {
        total: data?.length || 0,
        pending: data?.filter((r: { status: string }) => r.status === 'pending').length || 0,
        active: data?.filter((r: { status: string }) => r.status === 'active').length || 0,
        completed: data?.filter((r: { status: string }) => r.status === 'completed').length || 0,
        cancelled: data?.filter((r: { status: string }) => r.status === 'cancelled').length || 0,
        totalRevenue: data?.reduce((sum: number, r: { total_amount: string }) => sum + (parseFloat(r.total_amount) || 0), 0) || 0
      };

      log(method, path, 200);
      return createResponse({ stats });
    }

    // ==================== USER PROFILE ROUTES ====================
    if (path === '/users/profile' && method === 'GET') {
      const user = await getUser(req);
      if (!user) {
        log(method, path, 401);
        return errorResponse('Not authenticated', 401);
      }

      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      log(method, path, 200);
      return createResponse({ user: profile });
    }

    if (path === '/users/profile' && method === 'PUT') {
      const user = await getUser(req);
      if (!user) {
        log(method, path, 401);
        return errorResponse('Not authenticated', 401);
      }

      const body = await parseBody(req);
      const updates: Record<string, unknown> = {};
      if (body.fullName !== undefined) updates.full_name = body.fullName;
      if (body.phone !== undefined) updates.phone = body.phone;

      if (Object.keys(updates).length === 0) {
        log(method, path, 400);
        return errorResponse('No fields to update');
      }

      const { data, error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', user.id)
        .select()
        .single();

      if (error) {
        log(method, path, 500);
        return errorResponse(error.message, 500);
      }

      log(method, path, 200);
      return createResponse({ user: data });
    }

    // 404 for unmatched routes
    log(method, path, 404);
    return errorResponse('Route not found', 404);

  } catch (error) {
    console.error('[API ERROR]', error);
    return errorResponse('Internal server error', 500);
  }
});