/*
# Car Rental System - Initial Schema

This migration creates the core tables for a car rental application with multi-user support,
role-based access control, and complete rental lifecycle management.

## Tables Created

1. **profiles** - Extends Supabase auth.users with role-based access control
   - id (uuid, PK, references auth.users)
   - email (text, unique)
   - full_name (text)
   - role (text, default 'customer', check: 'admin' or 'customer')
   - phone (text, nullable)
   - created_at (timestamptz)

2. **categories** - Car categories/types
   - id (uuid, PK)
   - name (text, unique, not null)
   - description (text)
   - base_daily_rate (numeric)
   - created_at (timestamptz)

3. **cars** - Vehicle inventory
   - id (uuid, PK)
   - make (text, not null)
   - model (text, not null)
   - year (integer, not null)
   - license_plate (text, unique, not null)
   - category_id (uuid, FK to categories)
   - daily_rate (numeric, not null)
   - status (text, default 'available', check: 'available', 'rented', 'maintenance')
   - image_url (text, nullable)
   - features (text[], default '{}')
   - created_at (timestamptz)

4. **rentals** - Rental transactions
   - id (uuid, PK)
   - car_id (uuid, FK to cars)
   - user_id (uuid, FK to profiles)
   - start_date (date, not null)
   - end_date (date, not null)
   - total_amount (numeric, not null)
   - status (text, default 'pending', check: 'pending', 'active', 'completed', 'cancelled')
   - pickup_location (text)
   - return_location (text)
   - notes (text)
   - created_at (timestamptz)
   - updated_at (timestamptz)

## Security

- RLS enabled on all tables
- Owner-scoped policies for customer data (rentals)
- Admin override policies for car and category management
- Profile policies allow users to read/update their own data
- Admin role checked via profiles table join

## Notes

1. All tables use uuid primary keys with gen_random_uuid() defaults
2. Foreign keys use ON DELETE CASCADE where appropriate
3. Status fields use CHECK constraints for data integrity
4. Indexes added for frequently queried columns (user_id, car_id, status)
*/

-- Create profiles table (extends auth.users)
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  full_name text,
  role text NOT NULL DEFAULT 'customer' CHECK (role IN ('admin', 'customer')),
  phone text,
  created_at timestamptz DEFAULT now()
);

-- Create car categories table
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  description text,
  base_daily_rate numeric(10,2) NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create cars table
CREATE TABLE IF NOT EXISTS cars (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  make text NOT NULL,
  model text NOT NULL,
  year integer NOT NULL CHECK (year >= 1900 AND year <= EXTRACT(year FROM now()) + 1),
  license_plate text UNIQUE NOT NULL,
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  daily_rate numeric(10,2) NOT NULL CHECK (daily_rate >= 0),
  status text NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'rented', 'maintenance')),
  image_url text,
  features text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Create rentals table
CREATE TABLE IF NOT EXISTS rentals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  car_id uuid NOT NULL REFERENCES cars(id) ON DELETE RESTRICT,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  start_date date NOT NULL,
  end_date date NOT NULL,
  total_amount numeric(10,2) NOT NULL CHECK (total_amount >= 0),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'completed', 'cancelled')),
  pickup_location text,
  return_location text,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CHECK (end_date >= start_date)
);

-- Enable RLS on all tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE cars ENABLE ROW LEVEL SECURITY;
ALTER TABLE rentals ENABLE ROW LEVEL SECURITY;

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_cars_status ON cars(status);
CREATE INDEX IF NOT EXISTS idx_cars_category ON cars(category_id);
CREATE INDEX IF NOT EXISTS idx_rentals_user ON rentals(user_id);
CREATE INDEX IF NOT EXISTS idx_rentals_car ON rentals(car_id);
CREATE INDEX IF NOT EXISTS idx_rentals_status ON rentals(status);
CREATE INDEX IF NOT EXISTS idx_rentals_dates ON rentals(start_date, end_date);

-- Profiles policies
DROP POLICY IF EXISTS "users_read_own_profile" ON profiles;
CREATE POLICY "users_read_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id OR EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

DROP POLICY IF EXISTS "users_update_own_profile" ON profiles;
CREATE POLICY "users_update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "users_insert_profile" ON profiles;
CREATE POLICY "users_insert_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

-- Categories policies (public read, admin write)
DROP POLICY IF EXISTS "categories_read" ON categories;
CREATE POLICY "categories_read" ON categories FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "categories_admin_insert" ON categories;
CREATE POLICY "categories_admin_insert" ON categories FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

DROP POLICY IF EXISTS "categories_admin_update" ON categories;
CREATE POLICY "categories_admin_update" ON categories FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

DROP POLICY IF EXISTS "categories_admin_delete" ON categories;
CREATE POLICY "categories_admin_delete" ON categories FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Cars policies (public read, admin write)
DROP POLICY IF EXISTS "cars_read" ON cars;
CREATE POLICY "cars_read" ON cars FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "cars_admin_insert" ON cars;
CREATE POLICY "cars_admin_insert" ON cars FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

DROP POLICY IF EXISTS "cars_admin_update" ON cars;
CREATE POLICY "cars_admin_update" ON cars FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

DROP POLICY IF EXISTS "cars_admin_delete" ON cars;
CREATE POLICY "cars_admin_delete" ON cars FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Rentals policies (owner-scoped for customers, admin can see all)
DROP POLICY IF EXISTS "rentals_read" ON rentals;
CREATE POLICY "rentals_read" ON rentals FOR SELECT
  TO authenticated USING (
    auth.uid() = user_id OR EXISTS (
      SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
    )
  );

DROP POLICY IF EXISTS "rentals_customer_insert" ON rentals;
CREATE POLICY "rentals_customer_insert" ON rentals FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "rentals_customer_update" ON rentals;
CREATE POLICY "rentals_customer_update" ON rentals FOR UPDATE
  TO authenticated USING (
    auth.uid() = user_id OR EXISTS (
      SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
    )
  ) WITH CHECK (
    auth.uid() = user_id OR EXISTS (
      SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
    )
  );

DROP POLICY IF EXISTS "rentals_customer_delete" ON rentals;
CREATE POLICY "rentals_customer_delete" ON rentals FOR DELETE
  TO authenticated USING (
    (auth.uid() = user_id AND status = 'pending')
    OR EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Function to automatically create profile on user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, role)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'full_name', 'User'), 'customer');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to call the function on user creation
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS on_rental_update ON rentals;
CREATE TRIGGER on_rental_update
  BEFORE UPDATE ON rentals
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();