/*
# Car Rental System - Seed Data

This migration adds sample data for categories and cars to make the application usable immediately.

## Data Added

1. **Categories**: 4 common car types (Economy, Compact, SUV, Luxury)
2. **Cars**: 8 sample vehicles across different categories with realistic pricing and features

## Notes

1. All cars have detailed features arrays for filtering
2. Image URLs point to Pexels stock photos
3. License plates are fictional but realistic
*/

-- Insert categories
INSERT INTO categories (id, name, description, base_daily_rate) VALUES
  (gen_random_uuid(), 'Economy', 'Fuel-efficient, budget-friendly vehicles perfect for city driving', 35.00),
  (gen_random_uuid(), 'Compact', 'Balanced size and comfort, great for small families', 45.00),
  (gen_random_uuid(), 'SUV', 'Spacious vehicles with plenty of cargo room', 65.00),
  (gen_random_uuid(), 'Luxury', 'Premium vehicles with high-end features and comfort', 120.00);

-- Insert sample cars (using category ids from above)
INSERT INTO cars (make, model, year, license_plate, category_id, daily_rate, status, image_url, features)
SELECT 'Toyota', 'Corolla', 2024, 'ABC-1234', c.id, 38.00, 'available', 
  'https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg', 
  ARRAY['Automatic', 'Bluetooth', 'Backup Camera', 'Air Conditioning']
FROM categories c WHERE c.name = 'Economy' LIMIT 1;

INSERT INTO cars (make, model, year, license_plate, category_id, daily_rate, status, image_url, features)
SELECT 'Honda', 'Civic', 2023, 'XYZ-5678', c.id, 42.00, 'available',
  'https://images.pexels.com/photos/103290/pexels-photo-103290.jpeg',
  ARRAY['Automatic', 'Apple CarPlay', 'Android Auto', 'Lane Assist', 'Air Conditioning']
FROM categories c WHERE c.name = 'Compact' LIMIT 1;

INSERT INTO cars (make, model, year, license_plate, category_id, daily_rate, status, image_url, features)
SELECT 'Ford', 'Escape', 2024, 'SUV-9012', c.id, 68.00, 'available',
  'https://images.pexels.com/photos/103290/pexels-photo-103290.jpeg',
  ARRAY['Automatic', 'AWD', 'Navigation', 'Heated Seats', 'Bluetooth', 'Backup Camera']
FROM categories c WHERE c.name = 'SUV' LIMIT 1;

INSERT INTO cars (make, model, year, license_plate, category_id, daily_rate, status, image_url, features)
SELECT 'BMW', '5 Series', 2024, 'LUX-3456', c.id, 125.00, 'available',
  'https://images.pexels.com/photos/112610/pexels-photo-112610.jpeg',
  ARRAY['Automatic', 'Navigation', 'Leather Seats', 'Heated/Cooled Seats', 'Panoramic Roof', 'Premium Sound']
FROM categories c WHERE c.name = 'Luxury' LIMIT 1;

INSERT INTO cars (make, model, year, license_plate, category_id, daily_rate, status, image_url, features)
SELECT 'Hyundai', 'Elantra', 2023, 'ECO-7890', c.id, 36.00, 'available',
  'https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg',
  ARRAY['Automatic', 'Bluetooth', 'Air Conditioning', 'Cruise Control']
FROM categories c WHERE c.name = 'Economy' LIMIT 1;

INSERT INTO cars (make, model, year, license_plate, category_id, daily_rate, status, image_url, features)
SELECT 'Mazda', 'CX-5', 2024, 'SUV-2468', c.id, 72.00, 'rented',
  'https://images.pexels.com/photos/103290/pexels-photo-103290.jpeg',
  ARRAY['Automatic', 'AWD', 'Navigation', 'Heated Seats', 'Blind Spot Monitor']
FROM categories c WHERE c.name = 'SUV' LIMIT 1;

INSERT INTO cars (make, model, year, license_plate, category_id, daily_rate, status, image_url, features)
SELECT 'Nissan', 'Versa', 2023, 'ECO-1357', c.id, 32.00, 'available',
  'https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg',
  ARRAY['Automatic', 'Bluetooth', 'Air Conditioning']
FROM categories c WHERE c.name = 'Economy' LIMIT 1;

INSERT INTO cars (make, model, year, license_plate, category_id, daily_rate, status, image_url, features)
SELECT 'Mercedes', 'E-Class', 2024, 'LUX-9753', c.id, 140.00, 'maintenance',
  'https://images.pexels.com/photos/112610/pexels-photo-112610.jpeg',
  ARRAY['Automatic', 'Navigation', 'Leather Seats', 'Massage Seats', 'Premium Sound', 'Ambient Lighting']
FROM categories c WHERE c.name = 'Luxury' LIMIT 1;