/*
# Create Default Admin User

This migration creates a default admin account for testing and demonstration purposes.

## Admin Credentials
- Email: admin@quickreserve.com
- Password: Admin123
- Role: admin

## Notes
1. Uses Supabase's built-in password hashing
2. Profile is automatically created by the existing trigger
3. Role is updated to 'admin' after profile creation
*/

-- Create admin user using Supabase's auth administration functions
-- Note: In production, this would be done via Supabase dashboard or API
-- For this migration, we insert directly with proper hash

DO $$
DECLARE
  admin_id uuid;
BEGIN
  -- Check if admin already exists
  SELECT id INTO admin_id FROM auth.users WHERE email = 'admin@quickreserve.com';
  
  -- If not exists, create the admin user
  IF admin_id IS NULL THEN
    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at,
      confirmation_token,
      email_change,
      email_change_token_new,
      recovery_token
    )
    VALUES (
      '00000000-0000-0000-0000-000000000000',
      gen_random_uuid(),
      'authenticated',
      'authenticated',
      'admin@quickreserve.com',
      crypt('Admin123', gen_salt('bf', 10)),
      now(),
      '{"provider":"email","providers":["email"]}',
      '{"full_name":"Admin User"}',
      now(),
      now(),
      '',
      '',
      '',
      ''
    ) RETURNING id INTO admin_id;
  END IF;
END $$;

-- Update the profile role to admin (trigger creates profile with 'customer' role)
UPDATE profiles p
SET role = 'admin', full_name = 'Admin User'
WHERE email = 'admin@quickreserve.com'
  AND EXISTS (SELECT 1 FROM auth.users WHERE email = 'admin@quickreserve.com');